package com.issuetracking.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import com.issuetracking.model.RegistrationModel;
import com.issuetracking.dao.ConnectionDAO;
public class OperationDAO {
	private static Logger logger=LogManager.getLogger(OperationDAO.class);
	public String loginCheck(String username, String pass) {
		String role = "";
		Connection con = ConnectionDAO.getConnection();
		String cmd = "select roles from users where username=? and password=?";
		PreparedStatement pst=null;
		try {
			pst = con.prepareStatement(cmd);
			pst.setString(1, username);
			pst.setString(2, pass);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				role = rs.getString("roles");
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		finally{
			try{
				if(pst!=null)
					pst.close();
			}catch(SQLException e){
				logger.error(e.getMessage());
			}
			try{
				if(con!=null)
					con.close();
			}catch(SQLException e){
				logger.error(e.getMessage());
			}
		}
		return role;
	}

	public static boolean registration(RegistrationModel model) {
		Connection con = ConnectionDAO.getConnection();
		String cmd = "insert into users values(?,?,?,?,?,?,?)";
		PreparedStatement pst =null;
		try {
			pst= con.prepareStatement(cmd);
			pst.setString(1, model.getFirstName());
			pst.setString(2, model.getLastName());
			pst.setString(3, model.getEmail());
			pst.setString(4, model.getPhonenumber());
			pst.setString(5, model.getUsertype());
			pst.setString(6, model.getPass());
			pst.setString(7, model.getcPass());
			pst.executeUpdate();
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		finally{
			try{
				if(pst!=null)
					pst.close();
			}catch(SQLException e){
				logger.error(e.getMessage());
			}
			try{
				if(con!=null)
					con.close();
			}catch(SQLException e){
				logger.error(e.getMessage());
			}
		}
		return true;
	}

	public String generateissueId() {
		String id = "";
		String res = "";
		Connection con = ConnectionDAO.getConnection();
		String cmd = "select case when max(issue_id) is NULL then 'issue1' else max(issue_id) end issue_id from issue";
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			pst = con.prepareStatement(cmd);
			rs = pst.executeQuery();

			while (rs.next()) {
				id = rs.getString("issue_id");
			}
			int sid = Integer.parseInt(id.substring(5));
			sid++;

			if (sid >= 1) {
				res = "issue" + sid;
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		finally{
			try{
				if(rs!=null)
					rs.close();
			}catch(SQLException e){
				logger.error(e.getMessage());
			}
			try{
				if(pst!=null)
					pst.close();
			}catch(SQLException e){
				logger.error(e.getMessage());
			}
			try{
				if(con!=null)
					con.close();
			}catch(SQLException e){
				logger.error(e.getMessage());
			}
		}
		return res;

	}

	public boolean raiseIssue(String issue_id, String description, String status) {
		Connection con = ConnectionDAO.getConnection();
		String cmd = "insert into issue(issue_id,issue_desc,issue_status) values(?,?,?)";
		PreparedStatement pst =null;
		try {
			pst= con.prepareStatement(cmd);
			pst.setString(1, issue_id);
			pst.setString(2, description);
			pst.setString(3, status);
			pst.executeUpdate();

		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		finally{
			try{
				if(pst!=null)
					pst.close();
			}catch(SQLException e){
				logger.error(e.getMessage());
			}
			try{
				if(con!=null)
					con.close();
			}catch(SQLException e){
				logger.error(e.getMessage());
			}
		}
		return true;
	}

	public boolean changeDevid(String issue_id) {
		Connection con =ConnectionDAO.getConnection();
		String cmd = "update issue SET dev_id=null WHERE issue_id =?";
		PreparedStatement pst=null;
		try {
			pst = con.prepareStatement(cmd);
			pst.setString(1, issue_id);
			pst.executeUpdate();
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		finally{
			try{
				if(pst!=null)
					pst.close();
			}catch(SQLException e){
				logger.error(e.getMessage());
			}
			try{
				if(con!=null)
					con.close();
			}catch(SQLException e){
				logger.error(e.getMessage());
			}
		}
		return true;
	}

	public boolean changeStatus(String status, String issue_id) {
		Connection con = ConnectionDAO.getConnection();
		String cmd = "update issue SET issue_status=? WHERE issue_id = ?";
		PreparedStatement pst=null;
		try {
			pst = con.prepareStatement(cmd);
			pst.setString(1, status);
			pst.setString(2, issue_id);
			pst.executeUpdate();
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		finally{
			try{
				if(pst!=null)
					pst.close();
			}catch(SQLException e){
				logger.error(e.getMessage());
			}
			try{
				if(con!=null)
					con.close();
			}catch(SQLException e){
				logger.error(e.getMessage());
			}
		}
		return true;
	}

	public boolean addDeveloper(int rating, String dev_id, String issue_id) {
		Connection con = ConnectionDAO.getConnection();
		PreparedStatement pst=null;
		try {
			String cmd = "update issue SET rating=?, dev_id=? WHERE issue_id = ?";
			pst = con.prepareStatement(cmd);
			pst.setInt(1, rating);
			pst.setString(2, dev_id);
			pst.setString(3, issue_id);
			pst.executeUpdate();
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		finally{
			try{
				if(pst!=null)
					pst.close();
			}catch(SQLException e){
				logger.error(e.getMessage());
			}
			try{
				if(con!=null)
					con.close();
			}catch(SQLException e){
				logger.error(e.getMessage());
			}
		}
		return true;
	}
}
