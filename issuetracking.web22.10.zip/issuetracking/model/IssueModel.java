package com.issuetracking.model;

public class IssueModel {
	private String issue_id;
	private String issue_desc;
	private String issue_status;
	private String issue_dev_id;
	private int issue_type;
	private String issue_description;
	public String getIssue_id() {
		return issue_id;
	}
	public void setIssue_id(String issue_id) {
		this.issue_id = issue_id;
	}
	public String getIssue_desc() {
		return issue_desc;
	}
	public void setIssue_desc(String issue_desc) {
		this.issue_desc = issue_desc;
	}
	public String getIssue_status() {
		return issue_status;
	}
	public void setIssue_status(String issue_status) {
		this.issue_status = issue_status;
	}
	public String getIssue_dev_id() {
		return issue_dev_id;
	}
	public void setIssue_dev_id(String issue_dev_id) {
		this.issue_dev_id = issue_dev_id;
	}
	public int getIssue_type() {
		return issue_type;
	}
	public void setIssue_type(int issue_type) {
		this.issue_type = issue_type;
	}
	public String getIssue_description() {
		return issue_description;
	}
	public void setIssue_description(String issue_description) {
		this.issue_description = issue_description;
	}
}
