package com.issuetracking.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.issuetracking.dao.OperationDAO;
import com.issuetracking.model.RegistrationModel;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
	response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		RegistrationModel obj1=new RegistrationModel();
		String uname=request.getParameter("uname");
		obj1.setUsername(uname);
		obj1.setPass(request.getParameter("pass"));
		OperationDAO obj = new OperationDAO();
		String role = obj.loginCheck(obj1.getUsername(),obj1.getPass());
		if (role.equalsIgnoreCase("user")) {
			RequestDispatcher disp = request.getRequestDispatcher("User.jsp");
			disp.forward(request, response);
		} 
		else if (role.equals("developer")) {
			RequestDispatcher disp = request.getRequestDispatcher("DeveloperServlet");
			disp.forward(request, response);
		} 
		else if (role.equals("admin")) {
			RequestDispatcher disp = request.getRequestDispatcher("AdminServlet");
			disp.forward(request, response);
		} 
		else {
			out.println("Invalid credentials");
			RequestDispatcher disp=request.getRequestDispatcher("Welcome.html");
			disp.forward(request, response);
		}
	}
}