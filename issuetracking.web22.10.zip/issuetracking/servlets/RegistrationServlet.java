package com.issuetracking.servlets;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.issuetracking.dao.OperationDAO;
import com.issuetracking.model.RegistrationModel;

public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
	{
		response.getWriter().append("Served at:").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
	{
		response.setContentType("text/html");
		RegistrationModel model = new RegistrationModel();
		model.setUsername(request.getParameter("username"));
		model.setFirstName(request.getParameter("firstName"));
		model.setLastName(request.getParameter("lastname"));
		model.setEmail(request.getParameter("email"));
		model.setPhonenumber(request.getParameter("phonenumber"));
		model.setUsertype(request.getParameter("usertype"));
		model.setPass(request.getParameter("pass"));
		model.setcPass(request.getParameter("cPass"));
		if(OperationDAO.registration(model)==true)
		{
			RequestDispatcher dispatcher= request.getRequestDispatcher("Welcome.html");
			dispatcher.forward(request,response);
		}
	}
}