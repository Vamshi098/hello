package com.issuetracking.servlets;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.issuetracking.dao.OperationDAO;
import com.issuetracking.model.IssueModel;

@WebServlet("/UpdateAdmin")
public class UpdateAdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		doGet(request, response);
		IssueModel issue = new IssueModel();
		issue.setIssue_id(request.getParameter("issue_id"));
		issue.setIssue_type(Integer.parseInt(request.getParameter("issue_type")));
		issue.setIssue_dev_id(request.getParameter("issue_dev_id"));
		OperationDAO obj = new OperationDAO();
		if (obj.addDeveloper(issue.getIssue_type(), issue.getIssue_dev_id(), issue.getIssue_id()) == true) {
			RequestDispatcher disp = request.getRequestDispatcher("AdminServlet");
			disp.forward(request, response);
		}
	}
}
