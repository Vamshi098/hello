package com.issuetracking.servlets;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.issuetracking.dao.OperationDAO;
import com.issuetracking.model.IssueModel;

@WebServlet("/UpdateDeveloper")
public class UpdateDeveloperServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		OperationDAO obj=new OperationDAO();
		IssueModel issue=new IssueModel();
		issue.setIssue_status(request.getParameter("status"));
		issue.setIssue_id(request.getParameter("issue_id"));
		if(obj.changeStatus(issue.getIssue_status(),issue.getIssue_id())==true) {
			RequestDispatcher disp = request.getRequestDispatcher("DeveloperServlet");
			disp.forward(request, response);
		}
	}
}
