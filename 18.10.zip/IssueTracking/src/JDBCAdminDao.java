

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.issuetracking.entities.*;
import com.issuetracking.mergeDB.ConnectionManager;

public class JDBCAdminDao {
	
	public List<Developer> getDeveloperDetails() throws SQLException,ClassNotFoundException{
		
		Connection connection=ConnectionManager.openConnection();
		Statement statement=connection.createStatement();
		ResultSet resultSet=
				statement.executeQuery("select * from Developer");
		
		
		
		List<Developer> developerDetails=new ArrayList<Developer>();
		while(resultSet.next()) {
			
			Developer developer=new Developer();
			developer.setDeveloper_ID(resultSet.getString("developer_id"));
						
			
			developerDetails.add(developer);
		}
		ConnectionManager.closeConnection();
		return developerDetails;
	}
		
		
	

}
