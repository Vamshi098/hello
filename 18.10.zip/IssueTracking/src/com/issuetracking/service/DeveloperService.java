package com.issuetracking.service;

import java.util.List;

import com.issuetracking.entities.Developer;
import com.issuetracking.model.DeveloperModel;
import com.issuetracking.model.TicketClassModel;

public interface DeveloperService {
	
	public  List<DeveloperModel> retrieveDeveloperModel();
	

	public  DeveloperModel retrieveDeveloperId(int developerId);
	public String updateTicketStatus(TicketClassModel model) ;

	default  boolean  developerAuthenticate(Developer dev) {
		// TODO Auto-generated method stub
		return false;
	}
	
	
}
