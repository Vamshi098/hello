package com.issuetracking.service;

import java.sql.SQLException;
import java.util.List;

import com.issuetracking.entities.Admin;
import com.issuetracking.model.AdminModel;
import com.issuetracking.model.DeveloperModel;
import com.issuetracking.model.GuestModel;
import com.issuetracking.model.TicketClassModel;


public interface AdminService {
	
	public  List<DeveloperModel>  retrieveDevelopers() throws ClassNotFoundException , SQLException;
	public List<TicketClassModel> viewTickets()throws ClassNotFoundException, SQLException;
	
	
}
