package com.issuetracking.service;

import java.util.List;

import com.issuetracking.model.DeveloperModel;
import com.issuetracking.model.TicketClassModel;

public class DeveloperServiceImpl implements DeveloperService
{

	@Override
	public List<DeveloperModel> retrieveDeveloperModel() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public DeveloperModel retrieveDeveloperId(int developerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateTicketStatus(TicketClassModel model) {
		// TODO Auto-generated method stub
		return null;
	}

}
