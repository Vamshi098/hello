package com.issuetracking.view;

public class UserView {
	
	public void registerSuccess() {
		
		System.out.println("Registration successul");
	}
	
public void registerFail() {
		
		System.out.println("Registration failed");
	}

}
