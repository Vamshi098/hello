package com.issuetracking.view;

import java.util.Scanner;

public class DeveloperView extends MainView 
{
	public void developerView()
	{
		System.out.println("===================WELCOME TO THE DEVELOPER MENU==================");
		System.out.println("\n>>1. View Tickets");
		System.out.println(">>2. Assign Ticket");
		System.out.println(">>3. Unassign Ticket");
		System.out.println(">>4. Upload Patch Files");
		System.out.println(">>5. Search Ticket");
		System.out.println(">>6. Set Priority");
		System.out.println(">>7. Update Ticket");
		System.out.println(">>8. Export Ticket");
		System.out.println(">>9. Add Comments");
		System.out.println(">>10.Logout");

		try(Scanner scanner=new Scanner(System.in);){

			System.out.print("\nEnter Option:");
			int option=scanner.nextInt();

			switch(option)
			{
			case 1:viewTicket();
			break;
			case 2:assignTicket();
			break;
			case 3:unassignTicket();
			break;
			case 4:uploadPatchFiles();
			break;
			case 5:searchTicket();
			break;
			case 6:setPriority();
			break;
			case 7:updateTicket();
			break;
			case 8:exportTicket();
			break;
			case 9:addComment();
			break;
			case 10:logout();
			break;
			}

		}
		catch(Exception e) 
		{

		}
	}
	public void viewTicket() {
		try(Scanner scanner=new Scanner(System.in);)
		{

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}public void assignTicket() {
		try(Scanner scanner=new Scanner(System.in);)
		{

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}public void unassignTicket() {
		try(Scanner scanner=new Scanner(System.in);)
		{

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}public void uploadPatchFiles() {
		try(Scanner scanner=new Scanner(System.in);)
		{

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}public void searchTicket() {
		try(Scanner scanner=new Scanner(System.in);)
		{

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}public void setPriority() {
		try(Scanner scanner=new Scanner(System.in);)
		{

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}public void updateTicket() {
		try(Scanner scanner=new Scanner(System.in);)
		{
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}public void exportTicket() {
		try(Scanner scanner=new Scanner(System.in);)
		{

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}public void addComment() {
		try(Scanner scanner=new Scanner(System.in);)
		{

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void logout() {
		try(Scanner scanner=new Scanner(System.in);)
		{
			mainMenu();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

