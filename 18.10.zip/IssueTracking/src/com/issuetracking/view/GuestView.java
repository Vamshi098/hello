package com.issuetracking.view;

import java.util.Scanner;

public class GuestView extends MainView{
	
	//comments and changes such as adding new methods with implemntation
		
		public void guestView() 
		{
		System.out.println("============WELCOME TO THE GUEST MENU============");
		System.out.println("\n>> 1.Raise Tickets");
		System.out.println(">>   2. View ticket status");
		System.out.println(">>   3. Feedback for tickets");
		
	

	try(Scanner scanner=new Scanner(System.in);)
	{

		System.out.print("\nEnter Option:");
		int option=scanner.nextInt();

		switch(option)
		{
		case 1:RaiseTickets();
		break;
		case 2:ViewTicketStatus();
		break;
		case 3:FeedbackForTickets();
		break;
		case 4:logout();
		break;
		
		
		}

	  }
	catch(Exception e) 
	{
		
	}	
	}		
		
		
	private void logout() {
		
		
		
	}


	private void RaiseTickets() {		
		
		try(Scanner scanner=new Scanner(System.in);)
		{
			
			
			System.out.println("1.UserName:");
			String username = scanner.nextLine();
			
			System.out.println("2.ContactNumber:");
			int ContactNumber = scanner.nextInt();
			
			
			
			System.out.println("3.How critical is your issue ?\n*1 High\n*2 Medium\n*3 Low :");
			int input = scanner.nextInt();
			String critical;
							
			switch(input) {
			
			case 1 :critical = "High";
					break;
			case 2 :critical = "Medium";
					break;
			case 3 :critical = "Low";
					break;
					
			default:
				
				System.out.println("in default");
				try {
				throw new RuntimeException("not valid input");
				
				}catch(RuntimeException e) {
					System.out.println("invalid input system will shutdown");
					System.exit(0);
				}
				//critical= "Entered value is invalid Please select in between 1-3";
					//break;
					}
				
				
				//System.out.println(priority);
				//int priority = scanner.nextInt();
			
			System.out.println("4.Issue summary :  ");
			String summary = scanner.next();
			
			System.out.println("5. Main Menu");
			
			
			
			int menu=scanner.nextInt();
		
			if(menu==5)
				mainMenu();
			
		
			int option=scanner.nextInt();
			if(option==4)
				mainMenu();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		}

	private void ViewTicketStatus() {
		
		
		
	
	}

	private void FeedbackForTickets() {
		
		
		
		
	}
}
