package com.issuetracking.model;

public class TicketClassModel {

	public TicketClassModel() {
		
		
		
	}
			public int ticket_Id;
			public String ticket_Issue;
			public String ticket_Description;
			public int ticket_Developer_Id;
			public int ticket_Type;
			public int getTicket_Id() {
				return ticket_Id;
			}
			public void setTicket_Id(int ticket_Id) {
				this.ticket_Id = ticket_Id;
			}
			public String getTicket_Issue() {
				return ticket_Issue;
			}
			public void setTicket_Issue(String ticket_Issue) {
				this.ticket_Issue = ticket_Issue;
			}
			public String getTicket_Description() {
				return ticket_Description;
			}
			public void setTicket_Description(String ticket_Description) {
				this.ticket_Description = ticket_Description;
			}
			public int getTicket_Developer_Id() {
				return ticket_Developer_Id;
			}
			public void setTicket_Developer_Id(int ticket_Developer_Id) {
				this.ticket_Developer_Id = ticket_Developer_Id;
			}
			public int getTicket_Type() {
				return ticket_Type;
			}
			public void setTicket_Type(int ticket_Type) {
				this.ticket_Type = ticket_Type;
			}
			@Override
			public String toString() 
			{
				return "TicketClassModel [ticket_Id=" + ticket_Id + ", ticket_Issue=" + ticket_Issue
						+ ", ticket_Description=" + ticket_Description + ", ticket_Developer_Id=" + ticket_Developer_Id
						+ ", ticket_Type=" + ticket_Type + ", getTicket_Id()=" + getTicket_Id() + ", getTicket_Issue()="
						+ getTicket_Issue() + ", getTicket_Description()=" + getTicket_Description()
						+ ", getTicket_Developer_Id()=" + getTicket_Developer_Id() + ", getTicket_Type()="
						+ getTicket_Type() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
						+ ", toString()=" + super.toString() + "]";
			}
			@Override
			public int hashCode() {
				final int prime = 31;
				int result = 1;
				result = prime * result + ((ticket_Description == null) ? 0 : ticket_Description.hashCode());
				result = prime * result + ticket_Developer_Id;
				result = prime * result + ticket_Id;
				result = prime * result + ((ticket_Issue == null) ? 0 : ticket_Issue.hashCode());
				result = prime * result + ticket_Type;
				return result;
			}
			@Override
			public boolean equals(Object obj) {
				if (this == obj)
					return true;
				if (obj == null)
					return false;
				if (getClass() != obj.getClass())
					return false;
				TicketClassModel other = (TicketClassModel) obj;
				if (ticket_Description == null) {
					if (other.ticket_Description != null)
						return false;
				} else if (!ticket_Description.equals(other.ticket_Description))
					return false;
				if (ticket_Developer_Id != other.ticket_Developer_Id)
					return false;
				if (ticket_Id != other.ticket_Id)
					return false;
				if (ticket_Issue == null) {
					if (other.ticket_Issue != null)
						return false;
				} else if (!ticket_Issue.equals(other.ticket_Issue))
					return false;
				if (ticket_Type != other.ticket_Type)
					return false;
				return true;
			}
			
			
}
