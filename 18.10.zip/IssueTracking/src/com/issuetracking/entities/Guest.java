package com.issuetracking.entities;

public class Guest extends User{
	
	public Guest() {
		
	}
   
	protected String guest_ID;
	protected String guest_Name;
	
	private String guest_Email_Id;
	private String guest_password;
	
	protected String guest_Role_Id;
	protected String guest_Address;
	protected int guest_Mobile_No;
	public String getGuest_ID() {
		return guest_ID;
	}
	public void setGuest_ID(String guest_ID) {
		this.guest_ID = guest_ID;
	}
	public String getGuest_Name() {
		return guest_Name;
	}
	public void setGuest_Name(String guest_Name) {
		this.guest_Name = guest_Name;
	}
	public String getGuest_Email_Id() {
		return guest_Email_Id;
	}
	public void setGuest_Email_Id(String guest_Email_Id) {
		this.guest_Email_Id = guest_Email_Id;
	}
	public String getGuest_password() {
		return guest_password;
	}
	public void setGuest_password(String guest_password) {
		this.guest_password = guest_password;
	}
	public String getGuest_Role_Id() {
		return guest_Role_Id;
	}
	public void setGuest_Role_Id(String guest_Role_Id) {
		this.guest_Role_Id = guest_Role_Id;
	}
	public String getGuest_Address() {
		return guest_Address;
	}
	public void setGuest_Address(String guest_Address) {
		this.guest_Address = guest_Address;
	}
	public int getGuest_Mobile_No() {
		return guest_Mobile_No;
	}
	public void setGuest_Mobile_No(int guest_Mobile_No) {
		this.guest_Mobile_No = guest_Mobile_No;
	}
	@Override
	public String toString() {
		return "Guest [guest_ID=" + guest_ID + ", guest_Name=" + guest_Name + ", guest_Email_Id=" + guest_Email_Id
				+ ", guest_password=" + guest_password + ", guest_Role_Id=" + guest_Role_Id + ", guest_Address="
				+ guest_Address + ", guest_Mobile_No=" + guest_Mobile_No + ", user_ID=" + user_Id + ", user_Name="
				+ user_Name + ", user_Role_Id=" + user_Role_Id + ", user_Address=" + user_Address + ", user_Mobile_No="
				+ user_Mobile_No + ", getGuest_ID()=" + getGuest_ID() + ", getGuest_Name()=" + getGuest_Name()
				+ ", getGuest_Email_Id()=" + getGuest_Email_Id() + ", getGuest_password()=" + getGuest_password()
				+ ", getGuest_Role_Id()=" + getGuest_Role_Id() + ", getGuest_Address()=" + getGuest_Address()
				+ ", getGuest_Mobile_No()=" + getGuest_Mobile_No() + ", getUser_Mobile_No()=" + getUser_Mobile_No()
				+ ", getUser_ID()=" + getUser_Id() + ", getUser_Name()=" + getUser_Name() + ", getUser_Email_Id()="
				+ getUser_Email_Id() + ", getUser_password()=" + getUser_password() + ", getUser_Role_Id()="
				+ getUser_Role_Id() + ", getUser_Address()=" + getUser_Address() + ", toString()=" + super.toString()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}
	
	
	
	
	
}





	