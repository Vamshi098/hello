package com.issuetracking.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.issuetracking.mergeDB.ConnectionManager;
import com.issuetracking.model.DeveloperModel;
import com.issuetracking.model.TicketClassModel;


public class AdminDAOImpl implements AdminDAO 
{
	
	@Override
	public List<TicketClassModel> viewTickets() throws ClassNotFoundException, SQLException {
		
		System.out.print("dao called");
		Connection conn=ConnectionManager.openConnection();
		Statement statement=conn.createStatement();
		ResultSet resultSet=
				statement.executeQuery("select * from tickets");
		List<TicketClassModel> ticketClassModels=new ArrayList<TicketClassModel>();
		while(resultSet.next()) {
			TicketClassModel ticketClassModel = new TicketClassModel();
		
			ticketClassModel.setTicket_Id(resultSet.getInt("ticket_Id"));
			ticketClassModel.setTicket_Issue(resultSet.getString("ticket_Issue"));
			ticketClassModel.setTicket_Description(resultSet.getString("ticket_Description"));
			ticketClassModel.setTicket_Developer_Id(resultSet.getInt("ticket_Developer_Id"));
			ticketClassModel.setTicket_Type(resultSet.getInt("ticket_Type"));
			ticketClassModels.add(ticketClassModel);
			
		}
		ConnectionManager.closeConnection();
		return ticketClassModels;
	}

	@Override
	public List<DeveloperModel> retrieveDeveloper() throws ClassNotFoundException, SQLException 
	{
		Connection conn=ConnectionManager.openConnection();
		Statement statement=conn.createStatement();
		ResultSet resultSet=
				statement.executeQuery("select * from developer");
		List<DeveloperModel> developerModels= new ArrayList<DeveloperModel>();
		while(resultSet.next())
		{
			DeveloperModel developerModel = new DeveloperModel();
			developerModel.setDeveloper_ID(resultSet.getInt("developer_ID"));
			developerModel.setDeveloper_Email_ID(resultSet.getString("developer_Email_ID"));
			developerModel.setDeveloper_UserName(resultSet.getString("developer_UserName"));
			developerModel.setDeveloper_password(resultSet.getString("developer_password"));
			developerModel.setDeveloper_Address(resultSet.getString("developer_Address"));
			developerModel.setDeveloper_Mobile_No(resultSet.getInt("developer_Mobile_No"));
			developerModels.add(developerModel);
		}
		ConnectionManager.closeConnection();
		return developerModels;
	}

}
