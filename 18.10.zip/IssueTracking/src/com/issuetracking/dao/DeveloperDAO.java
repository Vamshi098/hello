package com.issuetracking.dao;

public interface DeveloperDAO {

}
