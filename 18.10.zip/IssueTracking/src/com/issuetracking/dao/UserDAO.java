package com.issuetracking.dao;

import java.sql.SQLException;

import com.issuetracking.entities.User;
import com.issuetracking.model.NewUserRegistrationModel;

public interface UserDAO {

	public boolean registerUser(User user)throws ClassNotFoundException,SQLException;
}
