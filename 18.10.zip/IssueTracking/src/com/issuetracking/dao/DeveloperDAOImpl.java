package com.issuetracking.dao;

public class DeveloperDAOImpl  implements DeveloperDAO
{
 
}
