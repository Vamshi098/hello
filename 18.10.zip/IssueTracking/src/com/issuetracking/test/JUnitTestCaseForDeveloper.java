/*
package com.issuetracking.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.issuetracking.entities.Developer;
import com.issuetracking.exception.DeveloperException;
import com.issuetracking.service.DeveloperService;

public class JUnitTestCaseForDeveloper 
{

	@Test
	public void testDeveloper_Positive() 
	{
	 DeveloperService developerService= new DeveloperService();		
		try
		{
		Developer dev =new Developer();
		dev.setDeveloper_ID("1788");
	    dev.setDeveloper_password("paddu5678");
		boolean actual=developerService.developerAuthenticate(dev);
		String expected="Developer View";
		assertEquals(expected,actual);
		}
		catch(DeveloperException e)
		{
			assertTrue(false);
		}
	}
	


	@Test
	public void testDeveloper_Negitive() 
	{
    DeveloperService developerService=new DeveloperService();	
		
		try
		{
		Developer dev =new Developer();
		dev.setDeveloper_ID("fueiwhff");
	    dev.setDeveloper_password("454frefregerg3423");
	     developerService.developerAuthenticate(dev);
		assertTrue(false);
		}
		catch(DeveloperException e)
		{
			assertTrue(true);
		}
	}
}

*/
	