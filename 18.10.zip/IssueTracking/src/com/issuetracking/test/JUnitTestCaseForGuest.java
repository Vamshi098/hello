/*
package com.issuetracking.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.issuetracking.entities.Admin;
import com.issuetracking.entities.Guest;
import com.issuetracking.exception.AdminException;
import com.issuetracking.exception.GuestException;
import com.issuetracking.service.GuestService;

public class JUnitTestCaseForGuest 
{

	@Test
	public void testGuest_Positive() 
	{
		GuestService guestService = new GuestService();
		try
		{
		Guest guest =new Guest();
		guest.setGuest_ID("1786");
		guest.setGuest_password("aman12345");
		boolean actual=guestService.guestAuthenticate(guest);
		String expected="Guest View";
		assertEquals(expected,actual);
		}
		catch(GuestException e)
		{
			assertTrue(false);
		}
	}

	@Test
	public void testGuest_Negitive() 
	{
		GuestService guestService = new GuestService();
		try
		{
		Guest guest =new Guest();
		guest.setGuest_ID("f4983u43");
		guest.setGuest_password("38r3u48hff");
		guestService.guestAuthenticate(guest);
		assertTrue(false);
		}
		catch(GuestException e)
		{
			assertTrue(true);
		}
	}
}
*/