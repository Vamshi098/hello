package com.issuetracking.exception;

public class AdminException extends Exception 
{

}
