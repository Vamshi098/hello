package com.issuetracking.exception;

public class DeveloperException extends Exception {

}
