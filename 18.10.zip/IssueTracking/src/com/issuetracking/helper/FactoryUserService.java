package com.issuetracking.helper;

import com.issuetracking.service.UserService;
import com.issuetracking.service.UserServiceImpl;

public class FactoryUserService 
{
   public static UserService createUserService() {
	   
	   UserService userService=new UserServiceImpl();
	   return userService;
	   
   }
}
