package com.issuetracking.helper;

import com.issuetracking.service.AdminService;
import com.issuetracking.service.AdminServiceImpl;

public class FactoryAdminService 
{
  public static AdminService createAdminService()
  {
	  AdminService adminService=new AdminServiceImpl();
	return adminService;
	  
  }
}
