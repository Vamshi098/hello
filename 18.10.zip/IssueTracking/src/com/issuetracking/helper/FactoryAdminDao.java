package com.issuetracking.helper;

import com.issuetracking.dao.AdminDAO;
import com.issuetracking.dao.AdminDAOImpl;



public class FactoryAdminDao {
	
	

	public static AdminDAO createAdminService() {
		// TODO Auto-generated method stub
		AdminDAO adminDao=new AdminDAOImpl();
		return adminDao;
	}
	
}
