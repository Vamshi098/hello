package com.virtusa.model;

public class UserModel {
	
	public UserModel() {}
	private int empId;
	private String password;
	private String userType;
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "UserModel [empId=" + empId + ", password=" + password + ", userType=" + userType + "]";
	}
	

}
