package com.virtusa.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.entities.Leaves;
import com.virtusa.integrate.ConnectionManager;
import com.virtusa.model.LeaveBalance;


public class ManagerDAO {
	public List<Leaves> getListOfLeaves() throws ClassNotFoundException, SQLException {
		Connection connection=ConnectionManager.openConnection();
		Statement statement=connection.createStatement();
		ResultSet resultSet=
				statement.executeQuery("select * from Leaves");
		List<Leaves> listOfLeaveRequest=new ArrayList<Leaves>();
		while(resultSet.next()) {
			Leaves leaves=new Leaves();
			leaves.setLeave_Id(resultSet.getString("leave_Id"));
			leaves.setEmp_Id(resultSet.getString("emp_Id"));
			leaves.setLeave_Type(resultSet.getString("leave_Type"));
			leaves.setLeave_Balances(resultSet.getString("leave_Balances"));
			leaves.setLeave_Status(resultSet.getString("leave_Status"));
			leaves.setFrom_Date(resultSet.getString("from_Date"));
			leaves.setTo_Date(resultSet.getString("to_Date"));
			leaves.setDesignation(resultSet.getString("designation"));
			leaves.setLeave_Desc(resultSet.getString("leave_Desc"));
			listOfLeaveRequest.add(leaves);
			System.out.println(leaves);
		}
		ConnectionManager.closeConnection();
		return listOfLeaveRequest;
	}
	public List<LeaveBalance> checkLeaveBalances() throws ClassNotFoundException, SQLException{
		Connection connection=ConnectionManager.openConnection();
		Statement statement=connection.createStatement();
		ResultSet resultSet=
				statement.executeQuery("select * from Leavebalance");
		List<LeaveBalance> leaveBalance=new ArrayList<LeaveBalance>();
			while(resultSet.next()) {
				LeaveBalance leaveBal=new LeaveBalance();
				leaveBal.setEmp_id(resultSet.getInt("emp_id"));
				leaveBal.setSick_leaves(resultSet.getInt("sick_leaves"));
				leaveBal.setEarned_leaves(resultSet.getInt("earned_leaves"));
				leaveBal.setBevarement_leaves(resultSet.getInt("bevarement_leaves"));
				leaveBalance.add(leaveBal);
				
			}
			ConnectionManager.closeConnection();
			return leaveBalance;
	}
}