package com.virtusa.controller;

import java.sql.SQLException;

import com.virtusa.dao.ManagerDAO;

public class ManagerController {

	public void viewListOfLeaveRequests() throws ClassNotFoundException, SQLException {
		ManagerDAO managerDAO=new ManagerDAO();
		managerDAO.getListOfLeaves();
	
	}
	public void leavebalances() throws ClassNotFoundException, SQLException {
		ManagerDAO managerDAO=new ManagerDAO();
		managerDAO.checkLeaveBalances();
	
	}

}
