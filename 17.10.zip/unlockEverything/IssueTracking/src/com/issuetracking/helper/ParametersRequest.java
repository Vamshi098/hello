package com.issuetracking.helper;

public enum ParametersRequest {
	
	NAME("name"),EMAIL_ID("email_id"),TICKET_Id("Ticket_Id");
	
	private String val;
	private ParametersRequest(String val) {
		
		this.val=val;
	}
	
	public String getVal() {
		return val;
	}

}
