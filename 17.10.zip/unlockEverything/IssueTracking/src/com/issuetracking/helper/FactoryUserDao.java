package com.issuetracking.helper;

import com.issuetracking.dao.UserDAO;
import com.issuetracking.dao.UserDAOImpl;

public class FactoryUserDao {

	public static UserDAO createUserService() {
		UserDAO userDao=new UserDAOImpl();
		return userDao;
	}
}
