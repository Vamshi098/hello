package com.issuetracking.exception;

public class NoTicketFoundException {
	
	String message;
	
	public NoTicketFoundException(String message) {
		this.message=message;
	}
	
	public String getMessage() {
		return message;
	}
}
