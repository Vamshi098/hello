package com.issuetracking.service;

import java.sql.SQLException;
import java.util.List;

import com.issuetracking.dao.AdminDAO;
import com.issuetracking.dao.UserDAO;
import com.issuetracking.entities.User;
import com.issuetracking.helper.FactoryAdminDao;
import com.issuetracking.helper.FactoryUserDao;
import com.issuetracking.model.AdminModel;
import com.issuetracking.model.NewUserRegistrationModel;
import com.issuetracking.model.TicketClassModel;


public class AdminServiceImpl implements AdminService 
{
		private AdminDAO adminDao;
		public AdminServiceImpl() {
			this.adminDao=FactoryAdminDao.createAdminService();
		}
		public String registerUser(NewUserRegistrationModel model)
		{
			// TODO Auto-generated method stub
			String result="";
			
	
			boolean outcome=false;
			/*try {
				outcome = AdminDAO.retrieveDeveloper();
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			return result;
	

}

		@Override
		public List<AdminModel> retrieveDevelopers() {
			// TODO Auto-generated method stub
			return null;
		}
		@Override
		public List<TicketClassModel> viewTickets() throws ClassNotFoundException, SQLException {
			// TODO Auto-generated method stub
			System.out.print("service");
			List<TicketClassModel> list=adminDao.viewTickets();
			return list;
		}}