package com.issuetracking.service;

import java.util.List;

import com.issuetracking.entities.Guest;
import com.issuetracking.model.GuestModel;
import com.issuetracking.model.NewUserRegistrationModel;

public interface GuestService {
	
	
	public List<GuestModel> retrieveGuestDetails();
	public GuestModel retriveGuestId(int guest_id);
	public String registerNewUser(NewUserRegistrationModel model);
	
	default boolean  guestAuthenticate(Guest guest)
	{
		return false;
		
	}
	
}
