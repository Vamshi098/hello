package com.issuetracking.entities;

public class Tracking {
	
	private int ticket_Id;
	private int ticket_Type;
	private String ticket_Description;
	private int ticket_Date_Time;
	public int getTicket_Id() {
		return ticket_Id;
	}
	public void setTicket_Id(int ticket_Id) {
		this.ticket_Id = ticket_Id;
	}
	public int getTicket_Type() {
		return ticket_Type;
	}
	public void setTicket_Type(int ticket_Type) {
		this.ticket_Type = ticket_Type;
	}
	public String getTicket_Description() {
		return ticket_Description;
	}
	public void setTicket_Description(String ticket_Description) {
		this.ticket_Description = ticket_Description;
	}
	public int getTicket_Date_Time() {
		return ticket_Date_Time;
	}
	public void setTicket_Date_Time(int ticket_Date_Time) {
		this.ticket_Date_Time = ticket_Date_Time;
	}
	@Override
	public String toString() {
		return "Tracking [ticket_Id=" + ticket_Id + ", ticket_Type=" + ticket_Type + ", ticket_Description="
				+ ticket_Description + ", ticket_Date_Time=" + ticket_Date_Time + ", getTicket_Id()=" + getTicket_Id()
				+ ", getTicket_Type()=" + getTicket_Type() + ", getTicket_Description()=" + getTicket_Description()
				+ ", getTicket_Date_Time()=" + getTicket_Date_Time() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}
	
}




