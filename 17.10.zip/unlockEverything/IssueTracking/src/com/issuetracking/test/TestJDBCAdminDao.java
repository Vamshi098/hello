package com.issuetracking.test;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.List;

import org.junit.Test;

import com.issuetracking.dao.JDBCAdminDao;
import com.issuetracking.entities.Developer;

public class TestJDBCAdminDao {

	@Test
	public void testGetDeveloperDetails() {
	
		JDBCAdminDao daoTest=new JDBCAdminDao();
		try {
			List<Developer> developerList=daoTest.getDeveloperDetails();
			assertEquals(true,developerList.size()>0);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			assertTrue(false);
			e.printStackTrace();
		}
	}

}
