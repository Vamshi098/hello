package com.issuetracking.dao;

import java.sql.Connection;
import java.sql.SQLException;

import com.issuetracking.entities.User;
import com.issuetracking.mergeDB.ConnectionManager;
import com.issuetracking.model.NewUserRegistrationModel;
import java.sql.PreparedStatement;

public class UserDAOImpl implements UserDAO{

	@Override
	public boolean registerUser(User user) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		Connection conn=ConnectionManager.openConnection();
		PreparedStatement statement=conn.prepareStatement("insert into user values(?,?,?,?,?,?,?)");
		statement.setInt(1,user.getUser_Id());
		statement.setString(2,user.getUser_Name());

		statement.setString(3,user.getUser_Email_Id());
		statement.setString(4,user.getUser_Address());
		statement.setString(5,user.getUser_Role_Id());
		statement.setString(6,user.getUser_password());
		statement.setInt(7,user.getUser_Mobile_No());
		int rows=statement.executeUpdate();
		if(rows>0)
			return true;
		else
			return false;
	}

}

