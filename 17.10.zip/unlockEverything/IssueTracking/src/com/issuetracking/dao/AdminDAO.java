package com.issuetracking.dao;

import java.sql.SQLException;
import java.util.List;

import com.issuetracking.model.TicketClassModel;

public interface AdminDAO {
	public List<TicketClassModel> viewTickets() throws ClassNotFoundException, SQLException;
}
