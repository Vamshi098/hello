package com.issuetracking.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.issuetracking.mergeDB.ConnectionManager;
import com.issuetracking.model.TicketClassModel;


public class AdminDAOImpl implements AdminDAO 
{
	
	@Override
	public List<TicketClassModel> viewTickets() throws ClassNotFoundException, SQLException {
		List<TicketClassModel> ticketClassModels=new ArrayList<TicketClassModel>();
		System.out.print("dao called");
		Connection conn=ConnectionManager.openConnection();
		Statement statement=conn.createStatement();
		ResultSet resultSet=
				statement.executeQuery("select * from tickets");
		while(resultSet.next()) {
			TicketClassModel ticketClassModel = new TicketClassModel();
			ticketClassModel.setTicket_Id(resultSet.getInt("ticket_Id"));
			ticketClassModel.setTicket_Issue(resultSet.getString("ticket_Issue"));
			ticketClassModel.setTicket_Description(resultSet.getString("ticket_Description"));
			ticketClassModel.setTicket_Developer_Id(resultSet.getInt("ticket_Developer_Id"));
			ticketClassModel.setTicket_Type(resultSet.getInt("ticket_Type"));
			ticketClassModels.add(ticketClassModel);

		}
		
		return ticketClassModels;
	}

}
