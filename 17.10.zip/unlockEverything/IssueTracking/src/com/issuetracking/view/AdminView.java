package com.issuetracking.view;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.issuetracking.controller.AdminController;
import com.issuetracking.mergeDB.ConnectionManager;
import com.issuetracking.model.AdminModel;
import com.issuetracking.model.TicketClassModel;

public class AdminView extends MainView
{
	
	AdminModel adminModel=new AdminModel();
	public void adminMainView()
	{
		
	System.out.println("============WELCOME TO THE ADMIN MENU============");
	System.out.println("\n>>1. View Tickets");
	System.out.println(">>2. Assign Ticket");
	System.out.println(">>3. Unassign Ticket");
	System.out.println(">>4. Close Ticket");
	System.out.println(">>5. Search Ticket");
	System.out.println(">>6. Logout");

	try(Scanner scanner=new Scanner(System.in);)
	{

		System.out.print("\nEnter Option:");
		int option=scanner.nextInt();

		switch(option)
		{
		case 1:AdminController controller=new AdminController();
			controller.handleviewTickets();
		break;
		case 2:assignTicket();
		break;
		case 3:unassignTicket();
		break;
		case 4:closeTicket();
		break;
		case 5:searchTicket();
		break;
		case 6:logout();
		break;
		}

	}
	catch(Exception e) 
	{
		
	}
	}
	public void viewTicket( List<TicketClassModel> ticketClassModels) {
		System.out.print("hello");
		System.out.println(((TicketClassModel) ticketClassModels).getTicket_Id());
		
		
			
	}
		public void assignTicket() {
			try(Scanner scanner=new Scanner(System.in);)
			{
				System.out.println("6. Main Menu");
				System.out.print("Enter choice:");
				int option=scanner.nextInt();

				if(option==6)
					mainMenu();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
			public void unassignTicket() {
				try(Scanner scanner=new Scanner(System.in);)
				{
					System.out.println("6. Main Menu");
					System.out.print("Enter choice:");
					int option=scanner.nextInt();

					if(option==6)
						mainMenu();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
				public void closeTicket() {
					try(Scanner scanner=new Scanner(System.in);)
					{
						System.out.println("6. Main Menu");
						System.out.print("Enter choice:");
						int option=scanner.nextInt();

						if(option==6)
							mainMenu();
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
				}
					public void searchTicket() {
						try(Scanner scanner=new Scanner(System.in);)
						{
							System.out.println("6. Main Menu");
							System.out.print("Enter choice:");
							int option=scanner.nextInt();

							if(option==6)
								mainMenu();
						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
					}
						public void logout() throws ClassNotFoundException, SQLException {
							try(Scanner scanner=new Scanner(System.in);)
							{
								mainMenu();
							}
							catch(Exception e)
							{
								e.printStackTrace();
							}
							
							
							AdminController adminController=new AdminController();
							
							adminController.handleretrieveDeveloper(adminModel);
							adminController.handleunassignTicket(adminModel);
							adminController.handlesearchTicketr(adminModel);
							adminController.handlecloseTicket(adminModel);
}
}