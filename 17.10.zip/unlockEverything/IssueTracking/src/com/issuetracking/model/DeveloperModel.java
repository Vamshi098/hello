package com.issuetracking.model;

public class DeveloperModel {

	public DeveloperModel() {

	}

	protected String developer_ID;
	protected String developer_Name;

	private String developer_Email_Id;
	private String developer_password;

	protected String developer_Role_Id;
	protected String developer_Address;
	protected int developer_Mobile_No;
	public String getDeveloper_ID() {
		return developer_ID;
	}
	public void setDeveloper_ID(String developer_ID) {
		this.developer_ID = developer_ID;
	}
	public String getDeveloper_Name() {
		return developer_Name;
	}
	public void setDeveloper_Name(String developer_Name) {
		this.developer_Name = developer_Name;
	}
	public String getDeveloper_Email_Id() {
		return developer_Email_Id;
	}
	public void setDeveloper_Email_Id(String developer_Email_Id) {
		this.developer_Email_Id = developer_Email_Id;
	}
	public String getDeveloper_password() {
		return developer_password;
	}
	public void setDeveloper_password(String developer_password) {
		this.developer_password = developer_password;
	}
	public String getDeveloper_Role_Id() {
		return developer_Role_Id;
	}
	public void setDeveloper_Role_Id(String developer_Role_Id) {
		this.developer_Role_Id = developer_Role_Id;
	}
	public String getDeveloper_Address() {
		return developer_Address;
	}
	public void setDeveloper_Address(String developer_Address) {
		this.developer_Address = developer_Address;
	}
	public int getDeveloper_Mobile_No() {
		return developer_Mobile_No;
	}
	public void setDeveloper_Mobile_No(int developer_Mobile_No) {
		this.developer_Mobile_No = developer_Mobile_No;
	}
	@Override
	public String toString() {
		return "DeveloperModel [developer_ID=" + developer_ID + ", developer_Name=" + developer_Name
				+ ", developer_Email_Id=" + developer_Email_Id + ", developer_password=" + developer_password
				+ ", developer_Role_Id=" + developer_Role_Id + ", developer_Address=" + developer_Address
				+ ", developer_Mobile_No=" + developer_Mobile_No + ", getDeveloper_ID()=" + getDeveloper_ID()
				+ ", getDeveloper_Name()=" + getDeveloper_Name() + ", getDeveloper_Email_Id()="
				+ getDeveloper_Email_Id() + ", getDeveloper_password()=" + getDeveloper_password()
				+ ", getDeveloper_Role_Id()=" + getDeveloper_Role_Id() + ", getDeveloper_Address()="
				+ getDeveloper_Address() + ", getDeveloper_Mobile_No()=" + getDeveloper_Mobile_No() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((developer_Address == null) ? 0 : developer_Address.hashCode());
		result = prime * result + ((developer_Email_Id == null) ? 0 : developer_Email_Id.hashCode());
		result = prime * result + ((developer_ID == null) ? 0 : developer_ID.hashCode());
		result = prime * result + developer_Mobile_No;
		result = prime * result + ((developer_Name == null) ? 0 : developer_Name.hashCode());
		result = prime * result + ((developer_Role_Id == null) ? 0 : developer_Role_Id.hashCode());
		result = prime * result + ((developer_password == null) ? 0 : developer_password.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DeveloperModel other = (DeveloperModel) obj;
		if (developer_Address == null) {
			if (other.developer_Address != null)
				return false;
		} else if (!developer_Address.equals(other.developer_Address))
			return false;
		if (developer_Email_Id == null) {
			if (other.developer_Email_Id != null)
				return false;
		} else if (!developer_Email_Id.equals(other.developer_Email_Id))
			return false;
		if (developer_ID == null) {
			if (other.developer_ID != null)
				return false;
		} else if (!developer_ID.equals(other.developer_ID))
			return false;
		if (developer_Mobile_No != other.developer_Mobile_No)
			return false;
		if (developer_Name == null) {
			if (other.developer_Name != null)
				return false;
		} else if (!developer_Name.equals(other.developer_Name))
			return false;
		if (developer_Role_Id == null) {
			if (other.developer_Role_Id != null)
				return false;
		} else if (!developer_Role_Id.equals(other.developer_Role_Id))
			return false;
		if (developer_password == null) {
			if (other.developer_password != null)
				return false;
		} else if (!developer_password.equals(other.developer_password))
			return false;
		return true;
	}


}


