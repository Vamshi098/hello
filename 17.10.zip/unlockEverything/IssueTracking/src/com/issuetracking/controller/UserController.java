package com.issuetracking.controller;

import com.issuetracking.helper.FactoryAdminService;
import com.issuetracking.helper.FactoryUserService;
import com.issuetracking.model.NewUserRegistrationModel;
import com.issuetracking.service.UserService;
import com.issuetracking.view.UserView;

public class UserController 
{
private UserService UserService;

public UserController() {
	
	this.UserService=FactoryUserService.createUserService();
}

public void handleRegistrationRequest(NewUserRegistrationModel model) {
	
	String output=UserService.registerUser(model);
	UserView userView=new UserView();
	if(output.contentEquals("success")) {
		userView.registerSuccess();
	}
}
}
