package com.issuetracking.controller;

import java.sql.SQLException;
import java.util.List;

import com.issuetracking.helper.FactoryAdminService;
import com.issuetracking.model.AdminModel;
import com.issuetracking.model.TicketClassModel;
import com.issuetracking.service.AdminService;
import com.issuetracking.view.AdminView;

public class AdminController 
{
	private  AdminService adminService;
  AdminView adminView =new AdminView();
  
  public AdminController()
  {
	  this.adminService=FactoryAdminService.createAdminService();
  }public void handleviewTickets() throws ClassNotFoundException, SQLException {
	  System.out.print("controller");
	  List<TicketClassModel> ticketClassModels=adminService.viewTickets();
	  adminView.viewTicket(ticketClassModels);
	  
}
  public void handleretrieveDeveloper(AdminModel adminModel) {

	
}public void handleunassignTicket(AdminModel adminModel) {

	
}public void handlecloseTicket(AdminModel adminModel) {

	
}
  
	  public void handlesearchTicketr(AdminModel adminModel) {

	
}

}
