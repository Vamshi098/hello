package com.virtusa.issueTrackingDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import com.virtusa.issueTracking.Registration;
import com.virtusa.issueTrackingDAO.DAOConnection;
public class DAOOperation {
	private static Logger logger=LogManager.getLogger(DAOOperation.class);
	public String loginCheck(String username, String pass) {
		String role = "";
		Connection con = DAOConnection.getConnection();
		String cmd = "select roles from users where username=? and password=?";
		PreparedStatement pst=null;
		try {
			pst = con.prepareStatement(cmd);
			pst.setString(1, username);
			pst.setString(2, pass);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				role = rs.getString("roles");
			}
		} catch (SQLException e) {
			 logger.error(e.getMessage());
		}
		finally{
		      try{
		         if(pst!=null)
		            pst.close();
		      }catch(SQLException e){
		    	  logger.error(e.getMessage());
		      }
		      try{
		         if(con!=null)
		            con.close();
		      }catch(SQLException e){
		    	  logger.error(e.getMessage());
		      }
		   }
		return role;
	}

	public static boolean registration(Registration obj) {
		Connection con = DAOConnection.getConnection();
		String cmd = "insert into users values(?,?,?,?,?,?,?,?,?)";
		PreparedStatement pst =null;
		try {
			pst= con.prepareStatement(cmd);
			pst.setString(1, obj.getUserName());
			pst.setString(2, obj.getEmail());
			pst.setString(3, obj.getFirstName());
			pst.setString(4, obj.getLastName());
			pst.setLong(5, obj.getPhNo());
			pst.setString(6, obj.getRole());
			pst.setString(7, obj.getPass());
			pst.setString(8, obj.getcPass());
			pst.setString(9, obj.getCity());
			pst.executeUpdate();
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		finally{
		      try{
		         if(pst!=null)
		            pst.close();
		      }catch(SQLException e){
		    	  logger.error(e.getMessage());
		      }
		      try{
		         if(con!=null)
		            con.close();
		      }catch(SQLException e){
		    	  logger.error(e.getMessage());
		      }
		   }
		return true;
	}

	public String generateissueId() {
		String id = "";
		String res = "";
		Connection con = DAOConnection.getConnection();
		String cmd = "select case when max(issue_id) is NULL then 'issue1' else max(issue_id) end issue_id from issue";
		PreparedStatement pst=null;
		ResultSet rs=null;
		try {
			pst = con.prepareStatement(cmd);
			rs = pst.executeQuery();

			while (rs.next()) {
				id = rs.getString("issue_id");
			}
			int sid = Integer.parseInt(id.substring(5));
			sid++;

			if (sid >= 1) {
				res = "issue" + sid;
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		finally{
			try{
		         if(rs!=null)
		            rs.close();
		      }catch(SQLException e){
		    	  logger.error(e.getMessage());
		      }
		      try{
		         if(pst!=null)
		            pst.close();
		      }catch(SQLException e){
		    	  logger.error(e.getMessage());
		      }
		      try{
		         if(con!=null)
		            con.close();
		      }catch(SQLException e){
		    	  logger.error(e.getMessage());
		      }
		   }
		return res;

	}

	public boolean raiseIssue(String issue_id, String description, String status) {
		Connection con = DAOConnection.getConnection();
		String cmd = "insert into issue(issue_id,issue_desc,issue_status) values(?,?,?)";
		PreparedStatement pst =null;
		try {
			pst= con.prepareStatement(cmd);
			pst.setString(1, issue_id);
			pst.setString(2, description);
			pst.setString(3, status);
			pst.executeUpdate();
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		finally{
		      try{
		         if(pst!=null)
		            pst.close();
		      }catch(SQLException e){
		    	  logger.error(e.getMessage());
		      }
		      try{
		         if(con!=null)
		            con.close();
		      }catch(SQLException e){
		    	  logger.error(e.getMessage());
		      }
		   }
		return true;
	}

	public boolean changeDevid(String issue_id) {
		Connection con = DAOConnection.getConnection();
		String cmd = "update issue SET dev_id=null WHERE issue_id =?";
		PreparedStatement pst=null;
		try {
			pst = con.prepareStatement(cmd);
			pst.setString(1, issue_id);
			pst.executeUpdate();
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		finally{
		      try{
		         if(pst!=null)
		            pst.close();
		      }catch(SQLException e){
		    	  logger.error(e.getMessage());
		      }
		      try{
		         if(con!=null)
		            con.close();
		      }catch(SQLException e){
		    	  logger.error(e.getMessage());
		      }
		   }
		return true;
	}

	public boolean changeStatus(String status, String issue_id) {
		Connection con = DAOConnection.getConnection();
		String cmd = "update issue SET issue_status=? WHERE issue_id = ?";
		PreparedStatement pst=null;
		try {
			pst = con.prepareStatement(cmd);
			pst.setString(1, status);
			pst.setString(2, issue_id);
			pst.executeUpdate();
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		finally{
		      try{
		         if(pst!=null)
		            pst.close();
		      }catch(SQLException e){
		    	  logger.error(e.getMessage());
		      }
		      try{
		         if(con!=null)
		            con.close();
		      }catch(SQLException e){
		    	  logger.error(e.getMessage());
		      }
		   }
		return true;
	}

	public boolean addDeveloper(int rating, String dev_id, String issue_id) {
		Connection con = DAOConnection.getConnection();
		PreparedStatement pst=null;
		try {
			String cmd = "update issue SET rating=?, dev_id=? WHERE issue_id = ?";
			pst = con.prepareStatement(cmd);
			pst.setInt(1, rating);
			pst.setString(2, dev_id);
			pst.setString(3, issue_id);
			pst.executeUpdate();
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		finally{
		      try{
		         if(pst!=null)
		            pst.close();
		      }catch(SQLException e){
		    	  logger.error(e.getMessage());
		      }
		      try{
		         if(con!=null)
		            con.close();
		      }catch(SQLException e){
		    	  logger.error(e.getMessage());
		      }
		   }
		return true;
	}
}
