package com.virtusa.IssueTrackingServelets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.virtusa.issueTracking.Registration;
import com.virtusa.issueTrackingDAO.DAOConnection;

/**
 * Servlet implementation class DeveloperServlet
 */
@WebServlet("/DeveloperServlet")
public class DeveloperServlet extends HttpServlet {
	private static Logger logger=LogManager.getLogger(DeveloperServlet.class);
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
		response.setContentType("text/html"); 
		PrintWriter out = response.getWriter();  
		Registration obj = new Registration();
		obj.setUserName(request.getParameter("uname"));
		String uname = obj.getUserName();
        out.println("<html><body>"); 
        out.println("<h2>list of issue Assigned by Admin :</h2>");
		out.println("<h1>Welcome  "+uname+"</h1>");
		out.println("<table border=1>");
		out.println("<tr><th>Issue_Id</th><th>Issue_desc</th><th>Issue_status</th><th>Rating</th><th>Update</th><th>Reject</th></tr>");
		Connection con = DAOConnection.getConnection();
		obj.setUserName(request.getParameter("uname"));
		String username=obj.getUserName();
		String cmd = "select issue_id,issue_desc,issue_status,rating from issue where dev_id=?";
		PreparedStatement pst = null;
		ResultSet rs=null;
		
		try {
			pst=con.prepareStatement(cmd);
			pst.setString(1,username);
			rs = pst.executeQuery(); 
			while (rs.next()) {
				String issue_id= rs.getString("issue_id");
				String issue_desc=rs.getString("issue_desc");
				String issue_status=rs.getString("issue_status");
				int rating =rs.getInt("rating");
				out.println("<tr><td>" +issue_id + "</td><td>" + issue_desc + "</td><td>" +issue_status + "</td><td>"+rating+"</td><td><a href=UpdateDeveloper.jsp?issue_id="+issue_id+">Update</a></td><td><a href=RejectDeveloper.jsp?issue_id="+issue_id+">Reject</a></td></tr>");
			}
			out.println("</table>"); 
			out.println("<a href=LogoutServlet>Logout</a>");
            out.println("</body></html>");
		} catch (SQLException e) {
		     logger.error(e.getMessage());

		}
		finally{
		      try{
		         if(rs!=null)
		            rs.close();
		      }catch(SQLException e){
		    	  logger.error(e.getMessage());
		      }
		      try{
			      if(pst!=null)
			         pst.close();
			      }catch(SQLException e){
			    	  logger.error(e.getMessage());
			      }
		      try{
		         if(con!=null)
		            con.close();
		      }catch(SQLException e){
		    	  logger.error(e.getMessage());
		      }
		   }
	}
}
