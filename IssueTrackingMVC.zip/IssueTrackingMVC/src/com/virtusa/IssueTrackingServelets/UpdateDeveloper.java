package com.virtusa.IssueTrackingServelets;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.virtusa.issueTracking.Issue;
import com.virtusa.issueTrackingDAO.DAOOperation;
/**
 * Servlet implementation class UpdateDeveloper
 */
@WebServlet("/UpdateDeveloper")
public class UpdateDeveloper extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DAOOperation obj=new DAOOperation();
		Issue issue=new Issue();
		issue.setIssue_status(request.getParameter("status"));
		issue.setIssue_id(request.getParameter("issue_id"));
		if(obj.changeStatus(issue.getIssue_status(),issue.getIssue_id())==true) {
			RequestDispatcher disp = request.getRequestDispatcher("DeveloperServlet");
			disp.forward(request, response);
		}
	}

}
