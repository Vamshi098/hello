package com.virtusa.IssueTrackingServelets;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.virtusa.issueTrackingDAO.DAOOperation;
/**
 * Servlet implementation class RejectDeveloper
 */
@WebServlet("/RejectDeveloper")
public class RejectDeveloper extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		DAOOperation obj=new DAOOperation();
		String issue_id=request.getParameter("issue_id");
		System.out.println(issue_id);
		if(obj.changeDevid(issue_id)==true) {
			RequestDispatcher disp = request.getRequestDispatcher("DeveloperServlet");
			disp.forward(request, response);
		}
		else {
			out.write("wrong");
			RequestDispatcher disp = request.getRequestDispatcher("RejectDeveloper");
			disp.include(request, response);
		}
	}

}
