package com.virtusa.IssueTrackingServelets;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.virtusa.issueTracking.Registration;
import com.virtusa.issueTrackingDAO.DAOOperation;

/**
 * Servlet implementation class RegistrationServelet
 */
@WebServlet("/RegistrationServelet")
public class RegistrationServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		Registration obj=new Registration();
		obj.setUserName(request.getParameter("username"));
		obj.setEmail(request.getParameter("email"));
		obj.setFirstName(request.getParameter("fname"));
		obj.setLastName(request.getParameter("lname"));
		obj.setPhNo(Long.parseLong(request.getParameter("phno")));
		obj.setRole(request.getParameter("role"));
		obj.setPass(request.getParameter("pass"));
		obj.setcPass(request.getParameter("cpass"));
		obj.setCity(request.getParameter("city"));
		if(DAOOperation.registration(obj)==true) {
		RequestDispatcher disp = request.getRequestDispatcher("Index.html");
		disp.forward(request, response);
		}
	}

}
