package com.virtusa.helper;
//hiding implementation details
import com.virtusa.dao.ManagerDAO;
import com.virtusa.dao.ManagerDAOImpl;
import com.virtusa.service.ManagerService;
import com.virtusa.service.ManagerServiceImpl;

public class FactoryManagerDB {

	public static ManagerDAO listLeavesManagerDAO(){
		ManagerDAO managerDAO=new ManagerDAOImpl();
		return managerDAO;
		
	}
	public static ManagerService listLeavesManagerService(){
		ManagerService employeesService=new ManagerServiceImpl();
		return employeesService;
	}
}
