package com.virtusa.model;
//ManagerleaveModel for retrieving leave balances
public class ManagerLeaveModel {

	private int emp_id;
	private int sick_leaves;
	private int earned_leaves;
	private int bevarement_leaves;
	public int getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	public int getSick_leaves() {
		return sick_leaves;
	}
	public void setSick_leaves(int sick_leaves) {
		this.sick_leaves = sick_leaves;
	}
	public int getEarned_leaves() {
		return earned_leaves;
	}
	public void setEarned_leaves(int earned_leaves) {
		this.earned_leaves = earned_leaves;
	}
	public int getBevarement_leaves() {
		return bevarement_leaves;
	}
	public void setBevarement_leaves(int bevarement_leaves) {
		this.bevarement_leaves = bevarement_leaves;
	}
	
	
}
