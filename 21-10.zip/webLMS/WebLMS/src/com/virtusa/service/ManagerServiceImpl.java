package com.virtusa.service;
import java.sql.Connection;

 

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.dao.ManagerDAO;
import com.virtusa.entities.Leaves;
import com.virtusa.helper.FactoryManagerDB;
import com.virtusa.integrate.ConnectionManager;
import com.virtusa.model.ManagerLeaveModel;
import com.virtusa.model.ManagerRetrieveList;


 

public class ManagerServiceImpl implements ManagerService {

 

    private ManagerDAO managerDAO=null;
    public ManagerServiceImpl() {
        this.managerDAO=FactoryManagerDB.listLeavesManagerDAO();
    }
    
    public List<ManagerLeaveModel> checkLeaveBalances(int empId, int leave_id) throws ClassNotFoundException, SQLException {
        Connection connection=ConnectionManager.openConnection();
        PreparedStatement statement1=connection.prepareStatement("select * from leavebalance where emp_id=?");
        statement1.setInt(1, empId);
        ResultSet resultSet1=statement1.executeQuery();
        
        List<ManagerLeaveModel> leaveDetails=new ArrayList<ManagerLeaveModel>();
        
        try {
        if(resultSet1.next()) {
        	ManagerLeaveModel managerLeaveModel=new ManagerLeaveModel();
            managerLeaveModel.setEmp_id(resultSet1.getInt("emp_id"));
            managerLeaveModel.setSick_leaves(resultSet1.getInt("sick_leaves"));
            managerLeaveModel.setEarned_leaves(resultSet1.getInt("Earned_Leaves"));
            managerLeaveModel.setBevarement_leaves(resultSet1.getInt("bevarement_leaves"));
            leaveDetails.add(managerLeaveModel);
            System.out.println(managerLeaveModel);
        }
        }
        catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        return leaveDetails;
}
    
    public void leaveApproval(int leaveId) throws ClassNotFoundException, SQLException {
        Connection connection=ConnectionManager.openConnection();
        PreparedStatement statement=connection.prepareStatement("update leaves_table set status='Approved' where leave_id=?");
        statement.setInt(1, leaveId);
        statement.executeUpdate();
        System.out.println("Successfully approved leave request");
    }
    public void leaveRejection(int leaveId) throws ClassNotFoundException, SQLException 
    {
        Connection connection=ConnectionManager.openConnection();
        PreparedStatement statement=connection.prepareStatement("update leaves_table set status='Rejected' where leave_id=?");
        statement.setInt(1, leaveId);
        statement.executeUpdate();
        System.out.println("Successfully Rejected leave request");
        connection.close();
    }
    
    /*public void leaveList() throws ClassNotFoundException, SQLException {
        ArrayList<Leaves> requestList = new ArrayList<>();
        
        ManagerDAOImpl managerDAOImpl=new ManagerDAOImpl();
        requestList = (ArrayList<Leaves>) managerDAOImpl.getListOfLeaves();
        for(int i =0; i<requestList.size();i++)
        {
            System.out.println(requestList.get(i).toString());
        }
    } 
    
        before implementation*/
    
    public List<ManagerRetrieveList> retrieveListOfLeaves() {
        // TODO Auto-generated method stub
        List<ManagerRetrieveList> allLeavesList=new ArrayList<>();
        try {
            List<Leaves> leaveList=managerDAO.getListOfLeaves();
            for(Leaves leaves:leaveList) {
                
                ManagerRetrieveList retrieveList=new ManagerRetrieveList();
                retrieveList.setEmp_Id(leaves.getEmpId());
                retrieveList.setLeave_Id(leaves.getLeaveId());
                retrieveList.setFrom_Date(leaves.getFromDate());
                retrieveList.setTo_Date(leaves.getToDate());
                retrieveList.setDesignation(leaves.getDesignation());
                retrieveList.setLeave_Type(leaves.getLeaveType());
                retrieveList.setStatus(leaves.getLeaveStatus());
                retrieveList.setLeave_desc(leaves.getLeaveDesc());
                allLeavesList.add(retrieveList);
                
            }
            
        } catch (ClassNotFoundException | SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
       
        return allLeavesList;
    }

 


}
 