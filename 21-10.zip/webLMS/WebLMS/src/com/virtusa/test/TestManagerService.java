package com.virtusa.test;

import static org.junit.Assert.*;
import java.sql.SQLException;
import java.util.List;
import org.junit.Test;
import com.virtusa.model.ManagerLeaveModel;
import com.virtusa.service.ManagerServiceImpl;


public class TestManagerService {
	//positive test case for TestManagerService
	@Test
	public void positive_Test() {
		
		ManagerServiceImpl managerServiceImpl=new ManagerServiceImpl();
		try {
			List<ManagerLeaveModel> leaveList=
					managerServiceImpl.checkLeaveBalances(100,1);
			assertEquals(true,leaveList.size()>0);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			assertTrue(false);
		}
	}

}
