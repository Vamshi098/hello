package com.virtusa.service;

import java.sql.SQLException;
import java.util.List;
import com.virtusa.model.ManagerLeaveModel;
import com.virtusa.model.ManagerRetrieveList;

public interface ManagerService {

	public void leaveApproval(int empId) throws ClassNotFoundException, SQLException;
	public void leaveRejection(int empId) throws ClassNotFoundException, SQLException;
	//public void leaveList() throws ClassNotFoundException, SQLException;
	public List<ManagerRetrieveList> retrieveListOfLeaves();
	public List<ManagerLeaveModel> checkLeaveBalances(int empId)throws ClassNotFoundException, SQLException;
}
