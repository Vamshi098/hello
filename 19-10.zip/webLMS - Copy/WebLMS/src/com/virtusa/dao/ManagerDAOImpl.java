package com.virtusa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.virtusa.entities.Leaves;
import com.virtusa.integrate.ConnectionManager;


public class ManagerDAOImpl implements ManagerDAO{
	public List<Leaves> getListOfLeaves() throws ClassNotFoundException, SQLException {
		Connection connection=ConnectionManager.openConnection();
		PreparedStatement statement=connection.prepareStatement("select * from leaves_table");
		ResultSet resultSet=statement.executeQuery();
		List<Leaves> listOfLeaveRequest=new ArrayList<Leaves>();
		while(resultSet.next()) {
			Leaves leaves=new Leaves();
			leaves.setLeaveId(resultSet.getInt("leave_id"));
			leaves.setEmpId(resultSet.getInt("emp_id"));
			leaves.setLeaveType(resultSet.getString("leave_type"));
			leaves.setLeaveStatus(resultSet.getString("status"));
			leaves.setFromDate(resultSet.getString("from_date"));
			leaves.setToDate(resultSet.getString("to_date"));
			leaves.setDesignation(resultSet.getString("designation"));
			leaves.setLeaveDesc(resultSet.getString("leave_description"));
			listOfLeaveRequest.add(leaves);
			//System.out.println(leaves);
		}
		connection.close();
		return listOfLeaveRequest;
	}
	
	
}