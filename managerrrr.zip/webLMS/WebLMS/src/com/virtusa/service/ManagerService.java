package com.virtusa.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.virtusa.entities.Leaves;

public interface ManagerService {

	public void leaveBalances() throws ClassNotFoundException, SQLException;
	public void leaveApproval(int empId) throws ClassNotFoundException, SQLException;
	public void leaveRejection(int empId) throws ClassNotFoundException, SQLException;
	public ArrayList<Leaves> LeaveList() throws ClassNotFoundException, SQLException;
}
