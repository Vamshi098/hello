package com.virtusa.controller;

import java.sql.SQLException;

import com.virtusa.dao.ManagerDAO;
import com.virtusa.helper.FactoryManagerDB;
import com.virtusa.service.ManagerService;
import com.virtusa.view.ManagerView;

public class ManagerController {
	private ManagerDAO managerDAO;
	private ManagerService managerService;
	public ManagerController() {
		this.managerDAO=FactoryManagerDB.listLeavesManagerDAO();
		this.managerService=FactoryManagerDB.listLeavesManagerService();
	}
	public void viewListOfLeaveRequests() throws ClassNotFoundException, SQLException 
	{
		/*ArrayList<Leaves> requestList = new ArrayList();
		
		ManagerDAO managerDAO=new ManagerDAO();
		requestList = (ArrayList<Leaves>) managerDAO.getListOfLeaves();
		for(int i =0; i<requestList.size();i++)
		{
			System.out.println(requestList.get(i).toString());
		}*/
		
		managerDAO.getListOfLeaves();
		managerService.leaveList();
	}
	public void leavebalances(int empId) throws ClassNotFoundException, SQLException {
		managerDAO.checkLeaveBalances(empId);
		
		/*ManagerService managerService=new ManagerService();
		managerService.leaveBalances();*/
	}
	public void approveLeave(int empId) throws ClassNotFoundException, SQLException {
		
		managerService.leaveApproval(empId);
		
		ManagerView managerView=new ManagerView();
		managerView.managerPage();
	}
	public void rejectLeave(int empId) throws ClassNotFoundException, SQLException {
		managerService.leaveRejection(empId);
		
		ManagerView managerView=new ManagerView();
		managerView.managerPage();
	}

}
