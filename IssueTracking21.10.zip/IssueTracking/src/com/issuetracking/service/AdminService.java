package com.issuetracking.service;

import java.sql.SQLException;
import java.util.List;
import com.issuetracking.model.DeveloperModel;
import com.issuetracking.model.TicketClassModel;

public interface AdminService {
	public  List<DeveloperModel>  retrieveDevelopers() throws ClassNotFoundException , SQLException;
	public List<TicketClassModel> viewTickets()throws ClassNotFoundException, SQLException;
	public List<DeveloperModel> retrieveunassignTicket() throws ClassNotFoundException, SQLException;
	public List<TicketClassModel> searchTickets() throws ClassNotFoundException, SQLException;
	public List<TicketClassModel> closeTickets() throws ClassNotFoundException,SQLException;		
}
