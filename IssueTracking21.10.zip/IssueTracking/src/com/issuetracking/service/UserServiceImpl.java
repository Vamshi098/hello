package com.issuetracking.service;

import java.sql.SQLException;

import com.issuetracking.dao.UserDAO;
import com.issuetracking.entities.User;
import com.issuetracking.helper.FactoryUserDao;
import com.issuetracking.model.NewUserRegistrationModel;

public class UserServiceImpl implements UserService {
	private UserDAO userDao;
	public UserServiceImpl() {
		this.userDao=FactoryUserDao.createUserService();
	}
	public String registerUser(NewUserRegistrationModel model)
	{
		// TODO Auto-generated method stub
		String result="";
		User user = new User();
		user.setUser_Name(model.getUser_Name());
		user.setUser_Id(model.getUser_Id());
		user.setUser_Email_Id(model.getUser_Email_Id());
		user.setUser_password(model.getUser_password());
		user.setUser_Role_Id(model.getUser_Role_Id());
		user.setUser_Mobile_No(model.getUser_Mobile_No());
		user.setUser_Address(model.getUser_Address());
		boolean outcome=false;
		try {
			outcome = userDao.registerUser(user);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(outcome) {
		result ="success";}
		else {
			result="fail";
	}
	return result;
}
}
