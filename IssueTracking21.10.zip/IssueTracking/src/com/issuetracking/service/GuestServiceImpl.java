package com.issuetracking.service;

import java.sql.SQLException;
import com.issuetracking.dao.GuestDAO;
import com.issuetracking.entities.Guest;
import com.issuetracking.helper.FactoryGuestDao;
import com.issuetracking.model.GuestModel;

public class GuestServiceImpl implements GuestService {
	private GuestDAO guestDao;
	public GuestServiceImpl() {
		this.guestDao=FactoryGuestDao.createGuestService();
	}
	public String raiseTicket(GuestModel guestModel) throws ClassNotFoundException, SQLException
	{
		String result ="";
		Guest guest = new Guest();
		guest.setUsername(guestModel.getUsername());
		guest.setMobileNumber(guestModel.getMobileNumber());
		guest.setIssue_Criticality(guestModel.getIssue_Criticality());
		guest.setIssue_Summary(guestModel.getIssue_Summary());
		boolean outcome = false;
		try
		{
		outcome = guestDao.raiseTicket(guest);
		}catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		if(outcome) {
			result ="Success";
		}else {
			result ="Fail";
		}
		return result;
	}
}