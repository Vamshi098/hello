package com.issuetracking.service;

import java.sql.SQLException;
import com.issuetracking.model.GuestModel;

public interface GuestService {
	public String raiseTicket(GuestModel guestModel) throws ClassNotFoundException, SQLException;
}
