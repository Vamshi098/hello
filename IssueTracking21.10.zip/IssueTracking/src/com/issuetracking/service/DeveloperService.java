package com.issuetracking.service;

import java.sql.SQLException;
import java.util.List;
import com.issuetracking.model.TicketClassModel;

public interface DeveloperService {
		public List<TicketClassModel> viewTickets() throws ClassNotFoundException, SQLException;
		public List<TicketClassModel> assignTickets() throws ClassNotFoundException, SQLException;
		public List<TicketClassModel> searchTickets() throws ClassNotFoundException,SQLException;
}
	