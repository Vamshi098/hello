package com.issuetracking.service;

import java.sql.SQLException;
import java.util.List;
import com.issuetracking.dao.AdminDAO;
import com.issuetracking.helper.FactoryAdminDao;
import com.issuetracking.model.DeveloperModel;
import com.issuetracking.model.NewUserRegistrationModel;
import com.issuetracking.model.TicketClassModel;

public class AdminServiceImpl implements AdminService 
{		private AdminDAO adminDao;
public AdminServiceImpl() {
	this.adminDao=FactoryAdminDao.createAdminService();
}
public String registerUser(NewUserRegistrationModel model)
{
	String result="";
	boolean outcome=false;			
	return result;
}		@Override
public List<DeveloperModel> retrieveDevelopers() throws ClassNotFoundException,SQLException
{
	System.out.println("service");
	List<DeveloperModel> list=adminDao.retrieveDeveloper();
	// TODO Auto-generated method stub
	return list;
}
@Override
public List<TicketClassModel> viewTickets() throws ClassNotFoundException, SQLException {

	System.out.print("service");
	List<TicketClassModel> list=adminDao.viewTickets();
	return list;
}
@Override
public List<DeveloperModel> retrieveunassignTicket() throws ClassNotFoundException, SQLException {
	List<DeveloperModel> list =adminDao.retrieveunaasignTicket();
	// TODO Auto-generated method stub
	return list;
}
@Override
public List<TicketClassModel> searchTickets() throws ClassNotFoundException, SQLException {
	List<TicketClassModel> ticketClassModels=adminDao.searchTickets();
	return ticketClassModels;
	// TODO Auto-generated method stub
}
@Override
public List<TicketClassModel> closeTickets() throws ClassNotFoundException, SQLException {
	List<TicketClassModel> ticketClassModels=adminDao.closeTickets();
	return ticketClassModels;
	// TODO Auto-generated method stub
}}