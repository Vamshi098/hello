package com.issuetracking.service;
import com.issuetracking.model.NewUserRegistrationModel;

public interface UserService {
	public String registerUser(NewUserRegistrationModel model);	
}
