package com.issuetracking.service;

import java.sql.SQLException;
import java.util.List;
import com.issuetracking.dao.DeveloperDAO;
import com.issuetracking.helper.FactoryDeveloperDao;
import com.issuetracking.model.TicketClassModel;

public class DeveloperServiceImpl implements DeveloperService
{	private DeveloperDAO developerDao;
public DeveloperServiceImpl() {
	this.developerDao=FactoryDeveloperDao.createDeveloperService();
}
@Override
public List<TicketClassModel> viewTickets() throws ClassNotFoundException, SQLException {
	System.out.println("service");
	List<TicketClassModel> ticketClassModels=developerDao.viewTickets();
	return ticketClassModels;
}
@Override
public List<TicketClassModel> assignTickets() throws ClassNotFoundException, SQLException {
	List<TicketClassModel> ticketClassModels=developerDao.assignTickets();
	return ticketClassModels;
}
@Override
public List<TicketClassModel> searchTickets() throws ClassNotFoundException, SQLException {
	List<TicketClassModel> ticketClassModels=developerDao.searchTickets();
	return ticketClassModels;
}

}
