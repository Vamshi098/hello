package com.issuetracking.view;

import java.util.Scanner;
import com.issuetracking.controller.GuestController;
import com.issuetracking.model.GuestModel;

public class GuestView extends MainView{
		
	GuestModel guestModel = new GuestModel();
	public void guestView() 
	{
	System.out.println("============WELCOME TO THE GUEST MENU============");
	System.out.println("\n>> 1.Raise Tickets");
	System.out.println(">>   2. View ticket status");
	System.out.println(">>   3. Feedback for tickets");
	try(Scanner scanner=new Scanner(System.in);)
{
	System.out.print("\nEnter Option:");
	int option=scanner.nextInt();
	switch(option)
	{
	case 1:RaiseTickets();
	break;
	case 2:ViewTicketStatus();
	break;
	case 3:FeedbackForTickets();
	break;
	case 4:logout();
	break;
	}
  }
catch(Exception e) 
{}	
}		
private void logout() {
	mainMenu();	
}
private void RaiseTickets() {		
	
	try(Scanner scanner=new Scanner(System.in);)
		{	
		System.out.println("1.UserName:");
		String username = scanner.nextLine();
		System.out.println("2.ContactNumber:");
		int mobileNumber = scanner.nextInt();
		System.out.println("3.How critical is your issue ?\n*1 High\n*2 Medium\n*3 Low :");
		int input = scanner.nextInt();
		String issue_Criticality = null;
		switch(input) {
		case 1 :issue_Criticality = "High";
		break;
		case 2 :issue_Criticality = "Medium";
		break;
		case 3 :issue_Criticality = "Low";
		break;
		default:
		try {
			throw new RuntimeException("not valid input");
			}catch(RuntimeException e) {}
			System.out.println("4.Issue summary :  ");
			String issue_Summary = scanner.next();
			System.out.println("5. Main Menu");
			int menu=scanner.nextInt();
			if(menu==5)
			mainMenu();
			guestModel.setUsername(username);
			guestModel.setMobileNumber(mobileNumber);
			guestModel.setIssue_Criticality(issue_Criticality);
			guestModel.setIssue_Summary(issue_Summary);
			GuestController guestController = new GuestController();
			guestController.handleRaiseTicket(guestModel);
			int option=scanner.nextInt();
			if(option==4)
				mainMenu();
		}
			scanner.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		}
	private void ViewTicketStatus()
	{	
	System.out.println("You have not raised any ticket");
	}
	private void FeedbackForTickets() {
			Scanner sc = new Scanner(System.in);
			System.out.println("Please give your valueable feedback");	
			String feedback = sc.nextLine();
			sc.close();
	}
	public void registerSuccess() {
				
	}
}
	
