package com.issuetracking.view;

import com.issuetracking.view.AdminView;
import java.util.Scanner;
import com.issuetracking.controller.UserController;
import com.issuetracking.model.NewUserRegistrationModel;

public class MainView 
{	
	NewUserRegistrationModel newUserRegistrationModel = new NewUserRegistrationModel();
	public void mainMenu() 
	{
		System.out.println("\n===========================WELCOME TO ISSUE TRACKING SYSTEM===========================");
		System.out.println("\n>>1. Existing User? Sign in.");
		System.out.println(">>2. New User? Sign Up");
		System.out.println(">>3. View Sections");

		try(Scanner scanner=new Scanner(System.in);){

			System.out.print("\nEnter Option:");
			int option=scanner.nextInt();

			switch(option)
			{
			case 1:existingUser();
			break;
			case 2:newuser();
			break;
			case 3:viewSections();
			break;
			}
		}catch(Exception e) 
		{}
	}

	public void existingUser() 
	{
		try(Scanner scanner=new Scanner(System.in);)
		{
			System.out.println("1. Enter Your Username");
			String username = scanner.nextLine();
			System.out.println("2. Enter Your Password");
			String password = scanner.nextLine();
			System.out.println("3. Enter User Type");
			System.out.println(">>1 Admin");
			System.out.println(">>2 Developer");
			System.out.println(">>3 Guest");
					
			System.out.println("\n4. Main Menu");
			int usertype=scanner.nextInt();
			
			/*if(usertype==1)
			{
				username = "admin";
				password ="admin";*/
		
		  switch(usertype)
			{
			case 1:AdminView adminView = new AdminView();
				   adminView.adminMainView();
			break;
			case 2:DeveloperView developerView = new DeveloperView();
				   developerView.developerView();
			break;
			case 3:GuestView guestView = new GuestView();
				   guestView.guestView();
			break;
			case 4:mainMenu();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void newuser()
	{
		Scanner scanner=new Scanner(System.in);
		System.out.print("Enter your Name:");
		String user_Name=scanner.next();
		System.out.print("Enter your User ID:");
		int user_id=scanner.nextInt();
		System.out.print("Enter your Email:");
		String user_Email_Id=scanner.next();
		System.out.println("Enter your Address");
		String user_Address= scanner.next();
		System.out.print("Enter your Phone Number:");
		int user_Mobile_No=scanner.nextInt();
		System.out.println("Create a new Password");
		String user_password=scanner.next();
		System.out.println("Enter your Role Type");
		String user_Role_Id= scanner.next();
		
		newUserRegistrationModel.setUser_Name(user_Name);
		newUserRegistrationModel.setUser_Id(user_id);
		newUserRegistrationModel.setUser_Email_Id(user_Email_Id);
		newUserRegistrationModel.setUser_Address(user_Address);
		newUserRegistrationModel.setUser_Role_Id(user_Role_Id);
		newUserRegistrationModel.setUser_password(user_password);
		newUserRegistrationModel.setUser_Mobile_No(user_Mobile_No);
		
		UserController userController=new UserController();
		userController.handleRegistrationRequest(newUserRegistrationModel);
		
		scanner.close();
		}
		public void viewSections() {
		try(Scanner scanner=new Scanner(System.in);)
		{
			System.out.println("\n 1. Home");
			System.out.println("2. Admin");
			System.out.println("3. Developer");
			System.out.println("4. Guest");
			System.out.println("5. Issues");
			System.out.println("6. Main Menu");
			System.out.print("Enter choice:");
			int option=scanner.nextInt();

			if(option==6)
				mainMenu();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}



