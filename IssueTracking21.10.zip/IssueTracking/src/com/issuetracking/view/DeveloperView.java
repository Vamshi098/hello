package com.issuetracking.view;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.issuetracking.controller.DeveloperController;
import com.issuetracking.model.DeveloperModel;
import com.issuetracking.model.TicketClassModel;

public class DeveloperView extends MainView 
{
	DeveloperModel developermodel=new DeveloperModel();
	public void developerView()
	{
		System.out.println("===================WELCOME TO THE DEVELOPER MENU==================");
		System.out.println("\n>>1. View Tickets");
		System.out.println(">>2. Assign Ticket");
		System.out.println(">>3. Unassign Ticket");
		System.out.println(">>4. Search Ticket");
		System.out.println(">>5. Update Ticket");
		System.out.println(">>6.Logout");

		try(Scanner scanner=new Scanner(System.in);)
		{
			System.out.print("\nEnter Option:");
			int option=scanner.nextInt();
			switch(option)
			{
			case 1:viewTicket();
			break;
			case 2:assignTicket();
			break;
			case 3:unassignTicket();
			break;
			case 4:searchTicket();
			break;
			case 5:updateTicket();
			break;
			case 6:logout();
			break;
			}
		}
		catch(Exception e) 
		{}
	}
	public void viewTicket() {
		
		List<TicketClassModel> ticketClassModels=new ArrayList<>();
		DeveloperController developerController = new DeveloperController();
		try
		{
			ticketClassModels = developerController.handleviewTickets();
		}
		catch(ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		}
		System.out.format("%10s %20s %20s %20s %20s","TICKET ID","TICKET ISSUE","TICKET DESCRIPTION","DEVELOPER ID","TICKET TYPE");
		System.out.println();
	    System.out.println("----------------------------------------------------------------------------------------------------");
	    ticketClassModels.forEach((o)->{
			  System.out.format("%10s %20s %20s %20s %20s",o.getTicket_Id(),o.getTicket_Issue(),o.getTicket_Description(),o.getTicket_Developer_Id(),o.getTicket_Type());
			  System.out.println();
			}); 
  
  System.out.println("-----------------------------------------------------------------------------------------------------");
	}
	public void assignTicket() {
		
		List<TicketClassModel> ticketClassModels=new ArrayList<>();
		DeveloperController developerController = new DeveloperController();
		try
		{
			ticketClassModels = developerController.handleassignTickets();
		}
		catch(ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		}
		System.out.format("%10s %20s %20s %20s %20s","TICKET ID","TICKET ISSUE","TICKET DESCRIPTION","DEVELOPER ID","TICKET TYPE");
		System.out.println();
	    System.out.println("----------------------------------------------------------------------------------------------------");
		ticketClassModels.forEach((o)->{
			  System.out.format("%10s %20s %20s %20s %20s",o.getTicket_Id(),o.getTicket_Issue(),o.getTicket_Description(),o.getTicket_Developer_Id(),o.getTicket_Type());
			  System.out.println();
			}); 
    
    System.out.println("-----------------------------------------------------------------------------------------------------");
	}
    	public void unassignTicket() {
		try(Scanner scanner=new Scanner(System.in);)
		{

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void searchTicket() {
		
		List<TicketClassModel> ticketClassModels=new ArrayList<>();
		DeveloperController developerController = new DeveloperController();
		try
		{
			ticketClassModels = developerController.handlesearchTickets();
		}
		catch(ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		}
		System.out.format("%10s %20s %20s %20s %20s","TICKET ID","TICKET ISSUE","TICKET DESCRIPTION","DEVELOPER ID","TICKET TYPE");
		System.out.println();
	    System.out.println("----------------------------------------------------------------------------------------------------");
		ticketClassModels.forEach((o)->{
			  System.out.format("%10s %20s %20s %20s %20s",o.getTicket_Id(),o.getTicket_Issue(),o.getTicket_Description(),o.getTicket_Developer_Id(),o.getTicket_Type());
			  System.out.println();
			}); 
    
    System.out.println("-----------------------------------------------------------------------------------------------------");
	}
	public void updateTicket() {
		try(Scanner scanner=new Scanner(System.in);)
		{
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void logout() {
		try(Scanner scanner=new Scanner(System.in);)
		{
			mainMenu();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

