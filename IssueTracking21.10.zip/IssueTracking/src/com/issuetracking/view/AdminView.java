package com.issuetracking.view;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.issuetracking.controller.AdminController;
import com.issuetracking.model.AdminModel;
import com.issuetracking.model.DeveloperModel;
import com.issuetracking.model.TicketClassModel;

public class AdminView extends MainView
{
	AdminModel adminModel=new AdminModel();
	public void adminMainView()
	{
	System.out.println("============WELCOME TO THE ADMIN MENU============");
	System.out.println("\n>>1. View Tickets");
	System.out.println(">>2. Assign Ticket");
	System.out.println(">>3. Unassign Ticket");
	System.out.println(">>4. Close Ticket");
	System.out.println(">>5. Search Ticket");
	System.out.println(">>6. Logout");

	try(Scanner scanner=new Scanner(System.in);)
	{
		System.out.print("\nEnter Option:");
		int option=scanner.nextInt();
		switch(option)
		{
		case 1:viewTicket();
		break;
		case 2:assignTicket();
		break;
		case 3:unassignTicket();
		break;
		case 4:closeTicket();
		break;
		case 5:searchTicket();
		break;
		case 6:logout();
		break;
		}
	}
	catch(Exception e) 
	{}
}	public void viewTicket( ) {
		List<TicketClassModel> ticketClassModels=new ArrayList<>();
		AdminController adminController = new AdminController();
		
		try {
			ticketClassModels = adminController.handleviewTickets();
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
		
		System.out.format("%10s %20s %20s %20s %20s","TICKET ID","TICKET ISSUE","TICKET DESCRIPTION","DEVELOPER ID","TICKET TYPE");
		System.out.println();
	    System.out.println("----------------------------------------------------------------------------------------------------");
		ticketClassModels.forEach((o)->{
			  System.out.format("%10s %20s %20s %20s %20s",o.getTicket_Id(),o.getTicket_Issue(),o.getTicket_Description(),o.getTicket_Developer_Id(),o.getTicket_Type());
			  System.out.println();
			}); 
    
    System.out.println("-----------------------------------------------------------------------------------------------------");
	}
		public void assignTicket( ) {
			List<DeveloperModel> developerModels = new ArrayList<>();
			AdminController adminController = new AdminController();
			try{
				developerModels = adminController.handleretrieveDeveloper();
			}
			catch(ClassNotFoundException | SQLException e)
			{
				e.printStackTrace();
			}
			System.out.format("%10s %20s %20s %20s %20s","DEVELOPER ID","DEVELOPER EMAIL ID","DEVELOPER USERNAME","DEVELOPER PASSWORD","DEVELOPER ADDRESS","DEVELOPER MOBILE NO");
			System.out.println();
		    System.out.println("----------------------------------------------------------------------------------------------------");
			developerModels.forEach((o)->{
				  System.out.format("%10s %20s %20s %20s %20s",o.getDeveloper_ID(),o.getDeveloper_Email_ID(),o.getDeveloper_UserName(),o.getDeveloper_password(),o.getDeveloper_Address(),o.getDeveloper_Mobile_No());
				  System.out.println();
				}); 
	    
	    System.out.println("-----------------------------------------------------------------------------------------------------");
		}
			public void unassignTicket() {
				
				List<DeveloperModel> developerModels = new ArrayList<>();
				AdminController adminController = new AdminController();
				
				try
				{
					developerModels=adminController.handleunassignTicket();
				}
				catch(ClassNotFoundException | SQLException e)
				{
					e.printStackTrace();
				}
				
				developerModels.forEach((e)->
				{
					System.out.println(e.getDeveloper_ID());
				});
			}
				public void closeTicket() {
					
					List<TicketClassModel> ticketClassModels=new ArrayList<>();
					AdminController adminController = new AdminController();
					
					try
					{
						ticketClassModels = adminController.handlecloseTickets();
					}
					catch(ClassNotFoundException | SQLException e)
					{
						e.printStackTrace();
					}
					System.out.format("%10s %20s %20s %20s %20s","TICKET ID","TICKET ISSUE","TICKET DESCRIPTION","DEVELOPER ID","TICKET TYPE");
					System.out.println();
				    System.out.println("----------------------------------------------------------------------------------------------------");
					ticketClassModels.forEach((o)->{
						  System.out.format("%10s %20s %20s %20s %20s",o.getTicket_Id(),o.getTicket_Issue(),o.getTicket_Description(),o.getTicket_Developer_Id(),o.getTicket_Type());
						  System.out.println();
						}); 
			    
			    System.out.println("-----------------------------------------------------------------------------------------------------");
				}
					public void searchTicket() 
					{
						List<TicketClassModel> ticketClassModels=new ArrayList<>();
						AdminController adminController = new AdminController();
						
						try
						
							{
								ticketClassModels = adminController.handlesearchTickets();
							
							} catch (ClassNotFoundException | SQLException e) {
								
								e.printStackTrace();
							}
							
						System.out.format("%10s %20s %20s %20s %20s","TICKET ID","TICKET ISSUE","TICKET DESCRIPTION","DEVELOPER ID","TICKET TYPE");
						System.out.println();
					    System.out.println("----------------------------------------------------------------------------------------------------");
						ticketClassModels.forEach((o)->{
							  System.out.format("%10s %20s %20s %20s %20s",o.getTicket_Id(),o.getTicket_Issue(),o.getTicket_Description(),o.getTicket_Developer_Id(),o.getTicket_Type());
							  System.out.println();
							}); 
				    
				    System.out.println("-----------------------------------------------------------------------------------------------------");
					}
						public void logout() throws ClassNotFoundException, SQLException {
							try(Scanner scanner=new Scanner(System.in);)
							{
								mainMenu();
							}
							catch(Exception e)
							{
								e.printStackTrace();
							}
														
							AdminController adminController=new AdminController();
						
}
}