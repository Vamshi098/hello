package com.issuetracking.dao;
import java.sql.SQLException;
import com.issuetracking.entities.Guest;

public interface GuestDAO {
	public boolean raiseTicket(Guest guest) throws ClassNotFoundException,SQLException;
}
