package com.issuetracking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.issuetracking.entities.Guest;
import com.issuetracking.mergeDB.ConnectionManager;

public class GuestDAOImpl implements GuestDAO {
	public boolean raiseTicket(Guest guest) throws ClassNotFoundException, SQLException {
		Connection connection = ConnectionManager.openConnection();
		PreparedStatement statement =connection.prepareStatement("insert into raisedticket values(?,?,?,?)");
		statement.setString(1,guest.getUsername());
		statement.setInt(2,guest.getMobileNumber());
		statement.setString(3,guest.getIssue_Criticality());
		statement.setString(4,guest.getIssue_Summary());
		int rows=statement.executeUpdate();
		if(rows>0)
			return true;
		else
			return false;
	}
}
