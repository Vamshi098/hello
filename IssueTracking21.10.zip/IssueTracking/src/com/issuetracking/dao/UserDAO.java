package com.issuetracking.dao;

import java.sql.SQLException;

import com.issuetracking.entities.User;

public interface UserDAO {

	public boolean registerUser(User user)throws ClassNotFoundException,SQLException;
}
