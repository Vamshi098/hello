package com.issuetracking.dao;

import java.sql.SQLException;
import java.util.List;
import com.issuetracking.model.DeveloperModel;
import com.issuetracking.model.TicketClassModel;

public interface AdminDAO {
	public List<TicketClassModel> viewTickets() throws ClassNotFoundException, SQLException;
	public List<DeveloperModel> retrieveDeveloper() throws ClassNotFoundException, SQLException;
	public List<DeveloperModel> retrieveunaasignTicket() throws ClassNotFoundException,SQLException;
    public List<TicketClassModel> searchTickets() throws ClassNotFoundException, SQLException;
   	public List<TicketClassModel> closeTickets() throws ClassNotFoundException, SQLException;
}
