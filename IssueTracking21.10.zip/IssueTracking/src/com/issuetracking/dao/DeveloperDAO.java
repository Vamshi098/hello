package com.issuetracking.dao;

import java.sql.SQLException;
import java.util.List;
import com.issuetracking.model.TicketClassModel;

public interface DeveloperDAO {
	public List<TicketClassModel> viewTickets() throws ClassNotFoundException, SQLException;
	public List<TicketClassModel> searchTickets() throws ClassNotFoundException,SQLException;
	public List<TicketClassModel> assignTickets() throws ClassNotFoundException,SQLException;
}
