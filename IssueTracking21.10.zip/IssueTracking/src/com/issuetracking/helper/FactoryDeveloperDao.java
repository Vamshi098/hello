package com.issuetracking.helper;

import com.issuetracking.dao.DeveloperDAO;
import com.issuetracking.dao.DeveloperDAOImpl;

public class FactoryDeveloperDao {
	public static DeveloperDAO createDeveloperService() {
		// TODO Auto-generated method stub
		DeveloperDAO developerDao=new DeveloperDAOImpl();
		return developerDao;
	}
}
