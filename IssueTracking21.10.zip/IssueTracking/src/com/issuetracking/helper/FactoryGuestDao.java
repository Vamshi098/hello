package com.issuetracking.helper;

import com.issuetracking.dao.GuestDAO;
import com.issuetracking.dao.GuestDAOImpl;

public class FactoryGuestDao {
	public static GuestDAO createGuestService() {
		GuestDAO guestDao=new GuestDAOImpl();
		return guestDao;
	}

}