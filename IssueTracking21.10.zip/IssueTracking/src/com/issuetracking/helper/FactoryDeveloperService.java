package com.issuetracking.helper;

import com.issuetracking.service.DeveloperService;
import com.issuetracking.service.DeveloperServiceImpl;

public class FactoryDeveloperService {
	public static DeveloperService createDeveloperService() {
		DeveloperService developerService=new DeveloperServiceImpl();
		return developerService;
	}

}
