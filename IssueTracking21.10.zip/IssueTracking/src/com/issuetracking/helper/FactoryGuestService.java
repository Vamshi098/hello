package com.issuetracking.helper;

import com.issuetracking.service.GuestService;
import com.issuetracking.service.GuestServiceImpl;


public class FactoryGuestService {

	public static GuestService createGuestService() 
	{	 
		   GuestService guestService=new GuestServiceImpl();
		   return guestService;
			}
}
