package com.issuetracking.entities;

public class TicketClass {

	public TicketClass() {}
	public int ticket_Id;
	public String ticketIssue;
	public String ticketDescription;
	public int developer_Id;
	public int ticket_Type1;
	public int getTicket_Id() {
		return ticket_Id;
	}
	public void setTicket_Id(int ticket_Id) {
		this.ticket_Id = ticket_Id;
	}
	public String getTicketIssue() {
		return ticketIssue;
	}
	public void setTicketIssue(String ticketIssue) {
		this.ticketIssue = ticketIssue;
	}
	public String getTicketDescription() {
		return ticketDescription;
	}
	public void setTicketDescription(String ticketDescription) {
		this.ticketDescription = ticketDescription;
	}
	public int getDeveloper_Id() {
		return developer_Id;
	}
	public void setDeveloper_Id(int developer_Id) {
		this.developer_Id = developer_Id;
	}
	public int getTicke_Type() {
		return ticket_Type1;
	}
	public void setTicke_Type(int ticke_Type) {
		this.ticket_Type1 = ticke_Type;
	}
	public int ticket_Issue_Id;
	public int ticket_Type;

	public int ticket_Developer_Id;
	public String ticket_Title;

	public String ticket_Description;

	public int getTicket_Issue_Id() {
		return ticket_Issue_Id;
	}

	public void setTicket_Issue_Id(int ticket_Issue_Id) {
		this.ticket_Issue_Id = ticket_Issue_Id;
	}

	public int getTicket_Type() {
		return ticket_Type1;
	}

	public void setTicket_Type(int ticket_Type) {
		this.ticket_Type1 = ticket_Type;
	}

	public int getTicket_Developer_Id() {
		return ticket_Developer_Id;
	}

	public void setTicket_Developer_Id(int ticket_Developer_Id) {
		this.ticket_Developer_Id = ticket_Developer_Id;
	}

	public String getTicket_Title() {
		return ticket_Title;
	}

	public void setTicket_Title(String ticket_Title) {
		this.ticket_Title = ticket_Title;
	}

	public String getTicket_Description() {
		return ticket_Description;
	}

	public void setTicket_Description(String ticket_Description) {
		this.ticket_Description = ticket_Description;
	}

	@Override
	public String toString() {
		return "TicketClass [ticket_Issue_Id=" + ticket_Issue_Id + ", ticket_Type=" + ticket_Type1
				+ ", ticket_Developer_Id=" + ticket_Developer_Id + ", ticket_Title=" + ticket_Title
				+ ", ticket_Description=" + ticket_Description + ", getTicket_Issue_Id()=" + getTicket_Issue_Id()
				+ ", getTicket_Type()=" + getTicket_Type() + ", getTicket_Developer_Id()=" + getTicket_Developer_Id()
				+ ", getTicket_Title()=" + getTicket_Title() + ", getTicket_Description()=" + getTicket_Description()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
}
