package com.issuetracking.entities;

public class Admin extends User {
	public Admin() {

	}
	protected String admin_ID;
	protected String admin_Name;

	private String admin_Email_Id;
	private String admin_password;

	protected String admin_Role_Id;
	protected String admin_Address;
	protected int admin_Mobile_No;

	public String getAdmin_ID() {
		return admin_ID;
	}
	public void setAdmin_ID(String admin_ID) {
		this.admin_ID = admin_ID;
	}
	public String getAdmin_Name() {
		return admin_Name;
	}
	public void setAdmin_Name(String admin_Name) {
		this.admin_Name = admin_Name;
	}
	public String getAdmin_Email_Id() {
		return admin_Email_Id;
	}
	public void setAdmin_Email_Id(String admin_Email_Id) {
		this.admin_Email_Id = admin_Email_Id;
	}
	public String getAdmin_password() {
		return admin_password;
	}
	public void setAdmin_password(String admin_password) {
		this.admin_password = admin_password;
	}
	public String getAdmin_Role_Id() {
		return admin_Role_Id;
	}
	public void setAdmin_Role_Id(String admin_Role_Id) {
		this.admin_Role_Id = admin_Role_Id;
	}
	public String getAdmin_Address() {
		return admin_Address;
	}
	public void setAdmin_Address(String admin_Address) {
		this.admin_Address = admin_Address;
	}
	public int getAdmin_Mobile_No() {
		return admin_Mobile_No;
	}
	public void setAdmin_Mobile_No(int admin_Mobile_No) {
		this.admin_Mobile_No = admin_Mobile_No;
	}
	@Override
	public String toString() {
		return "Admin [admin_ID=" + admin_ID + ", admin_Name=" + admin_Name + ", admin_Email_Id=" + admin_Email_Id
				+ ", admin_password=" + admin_password + ", admin_Role_Id=" + admin_Role_Id + ", admin_Address="
				+ admin_Address + ", admin_Mobile_No=" + admin_Mobile_No + ", user_ID=" + user_Id + ", user_Name="
				+ user_Name + ", user_Role_Id=" + user_Role_Id + ", user_Address=" + user_Address + ", user_Mobile_No="
				+ user_Mobile_No + ", getAdmin_ID()=" + getAdmin_ID() + ", getAdmin_Name()=" + getAdmin_Name()
				+ ", getAdmin_Email_Id()=" + getAdmin_Email_Id() + ", getAdmin_password()=" + getAdmin_password()
				+ ", getAdmin_Role_Id()=" + getAdmin_Role_Id() + ", getAdmin_Address()=" + getAdmin_Address()
				+ ", getAdmin_Mobile_No()=" + getAdmin_Mobile_No() + ", getUser_Mobile_No()=" + getUser_Mobile_No()
				+ ", getUser_ID()=" + getUser_Id() + ", getUser_Name()=" + getUser_Name() + ", getUser_Email_Id()="
				+ getUser_Email_Id() + ", getUser_password()=" + getUser_password() + ", getUser_Role_Id()="
				+ getUser_Role_Id() + ", getUser_Address()=" + getUser_Address() + ", toString()=" + super.toString()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}
}





