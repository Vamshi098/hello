package com.issuetracking.entities;

public class Developer extends User {
	
	public Developer() {
		
	}	
	protected String developer_ID;
	protected String developer_Name;
	
	private String developer_Email_Id;
	private String developer_password;
	
	protected String developer_Role_Id;
	protected String developer_Address;
	protected int developer_Mobile_No;
		
	public String getDeveloper_ID() {
		return developer_ID;
	}
	public void setDeveloper_ID(String developer_ID) {
		this.developer_ID = developer_ID;
	}
	public String getDeveloper_Name() {
		return developer_Name;
	}
	public void setDeveloper_Name(String developer_Name) {
		this.developer_Name = developer_Name;
	}
	public String getDeveloper_Email_Id() {
		return developer_Email_Id;
	}
	public void setDeveloper_Email_Id(String developer_Email_Id) {
		this.developer_Email_Id = developer_Email_Id;
	}
	public String getDeveloper_password() {
		return developer_password;
	}
	public void setDeveloper_password(String developer_password) {
		this.developer_password = developer_password;
	}
	public String getDeveloper_Role_Id() {
		return developer_Role_Id;
	}
	public void setDeveloper_Role_Id(String developer_Role_Id) {
		this.developer_Role_Id = developer_Role_Id;
	}
	public String getDeveloper_Address() {
		return developer_Address;
	}
	public void setDeveloper_Address(String developer_Address) {
		this.developer_Address = developer_Address;
	}
	public int getDeveloper_Mobile_No() {
		return developer_Mobile_No;
	}
	public void setDeveloper_Mobile_No(int developer_Mobile_No) {
		this.developer_Mobile_No = developer_Mobile_No;
	}
	@Override
	public String toString() {
		return "Developer [developer_ID=" + developer_ID + ", developer_Name=" + developer_Name
				+ ", developer_Email_Id=" + developer_Email_Id + ", developer_password=" + developer_password
				+ ", developer_Role_Id=" + developer_Role_Id + ", developer_Address=" + developer_Address
				+ ", developer_Mobile_No=" + developer_Mobile_No + ", user_ID=" + user_Id + ", user_Name=" + user_Name
				+ ", user_Role_Id=" + user_Role_Id + ", user_Address=" + user_Address + ", user_Mobile_No="
				+ user_Mobile_No + ", getDeveloper_ID()=" + getDeveloper_ID() + ", getDeveloper_Name()="
				+ getDeveloper_Name() + ", getDeveloper_Email_Id()=" + getDeveloper_Email_Id()
				+ ", getDeveloper_password()=" + getDeveloper_password() + ", getDeveloper_Role_Id()="
				+ getDeveloper_Role_Id() + ", getDeveloper_Address()=" + getDeveloper_Address()
				+ ", getDeveloper_Mobile_No()=" + getDeveloper_Mobile_No() + ", getUser_Mobile_No()="
				+ getUser_Mobile_No() + ", getUser_ID()=" + getUser_Id() + ", getUser_Name()=" + getUser_Name()
				+ ", getUser_Email_Id()=" + getUser_Email_Id() + ", getUser_password()=" + getUser_password()
				+ ", getUser_Role_Id()=" + getUser_Role_Id() + ", getUser_Address()=" + getUser_Address()
				+ ", toString()=" + super.toString() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ "]";
	}
}



	