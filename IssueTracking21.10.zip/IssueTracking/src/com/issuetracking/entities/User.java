package com.issuetracking.entities;

public class User {

	public User(){}
	protected int user_Id;
	protected String user_Name;
	private  String user_Email_Id;
	private String user_password;
	protected String user_Role_Id;
	protected String user_Address;
	protected int user_Mobile_No;

	public int getUser_Id() {
		return user_Id;
	}
	public void setUser_Id(int user_Id) {
		this.user_Id = user_Id;
	}
	public String getUser_Name() {
		return user_Name;
	}
	public void setUser_Name(String user_Name) {
		this.user_Name = user_Name;
	}
	public String getUser_Email_Id() {
		return user_Email_Id;
	}
	public void setUser_Email_Id(String user_Email_Id) {
		this.user_Email_Id = user_Email_Id;
	}
	public String getUser_password() {
		return user_password;
	}
	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}
	public String getUser_Role_Id() {
		return user_Role_Id;
	}
	public void setUser_Role_Id(String user_Role_Id) {
		this.user_Role_Id = user_Role_Id;
	}
	public String getUser_Address() {
		return user_Address;
	}
	public void setUser_Address(String user_Address) {
		this.user_Address = user_Address;
	}
	public int getUser_Mobile_No() {
		return user_Mobile_No;
	}
	public void setUser_Mobile_No(int user_Mobile_No) {
		this.user_Mobile_No = user_Mobile_No;
	}
	@Override
	public String toString() {
		return "User [user_Id=" + user_Id + ", user_Name=" + user_Name + ", user_Email_Id=" + user_Email_Id
				+ ", user_password=" + user_password + ", user_Role_Id=" + user_Role_Id + ", user_Address="
				+ user_Address + ", user_Mobile_No=" + user_Mobile_No + ", getUser_Id()=" + getUser_Id()
				+ ", getUser_Name()=" + getUser_Name() + ", getUser_Email_Id()=" + getUser_Email_Id()
				+ ", getUser_password()=" + getUser_password() + ", getUser_Role_Id()=" + getUser_Role_Id()
				+ ", getUser_Address()=" + getUser_Address() + ", getUser_Mobile_No()=" + getUser_Mobile_No()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((user_Address == null) ? 0 : user_Address.hashCode());
		result = prime * result + ((user_Email_Id == null) ? 0 : user_Email_Id.hashCode());
		result = prime * result + user_Id;
		result = prime * result + user_Mobile_No;
		result = prime * result + ((user_Name == null) ? 0 : user_Name.hashCode());
		result = prime * result + ((user_Role_Id == null) ? 0 : user_Role_Id.hashCode());
		result = prime * result + ((user_password == null) ? 0 : user_password.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (user_Address == null) {
			if (other.user_Address != null)
				return false;
		} else if (!user_Address.equals(other.user_Address))
			return false;
		if (user_Email_Id == null) {
			if (other.user_Email_Id != null)
				return false;
		} else if (!user_Email_Id.equals(other.user_Email_Id))
			return false;
		if (user_Id != other.user_Id) {

			return false;
		} 
		if (user_Mobile_No != other.user_Mobile_No)
			return false;
		if (user_Name == null) {
			if (other.user_Name != null)
				return false;
		} else if (!user_Name.equals(other.user_Name))
			return false;
		if (user_Role_Id == null) {
			if (other.user_Role_Id != null)
				return false;
		} else if (!user_Role_Id.equals(other.user_Role_Id))
			return false;
		if (user_password == null) {
			if (other.user_password != null)
				return false;
		} else if (!user_password.equals(other.user_password))
			return false;
		return true;
	}
}

