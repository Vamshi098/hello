package com.issuetracking.entities;

public class Tracking {

	private int ticket_Id;
	private int ticket_Type;
	private String ticket_Description;
	private int ticket_Date_Time;
	
}




