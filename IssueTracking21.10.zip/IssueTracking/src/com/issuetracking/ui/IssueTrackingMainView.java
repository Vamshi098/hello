package com.issuetracking.ui;

import com.issuetracking.view.MainView;
public class IssueTrackingMainView {

	public static void main(String[] args) {
		MainView mainView=new MainView();
		mainView.mainMenu();
		}
}
