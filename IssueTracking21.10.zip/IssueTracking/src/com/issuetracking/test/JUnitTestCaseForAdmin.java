/*package com.issuetracking.test;
import static org.junit.Assert.*;
import org.junit.Test;
import com.issuetracking.entities.Admin;
import com.issuetracking.exception.AdminException;
import com.issuetracking.service.AdminService;
public class JUnitTestCaseForAdmin 
{
@Test
	public void testAdmin_Positive() 
	{
		AdminService adminservice=new AdminService();	
		try
		{
		Admin admin =new Admin();
		admin.setAdmin_ID("1789");
		admin.setAdmin_password("rajkumari1234");
		boolean actual=adminservice.adminAuthenticate(admin);
		String expected="Admin View";
		assertEquals(expected,actual);
		}
		catch(AdminException e)
		{
			assertTrue(false);
		}
	}
	@Test
	public void testAdmin_Negtive() 
	{
		AdminService adminservice=new AdminService();	
		try
		{
		Admin admin =new Admin();
		admin.setAdmin_ID("nf845htn");
		admin.setAdmin_password("3847328rhfnfurtgg");
		adminservice.adminAuthenticate(admin);
		assertTrue(false);
		}
		catch(AdminException e)
		{
			assertTrue(true);
		}
	}

}
*/