package com.issuetracking.test;

public class LoginCredentials {
	//junit

}
