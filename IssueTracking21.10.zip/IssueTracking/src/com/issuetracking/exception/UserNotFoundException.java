package com.issuetracking.exception;

public class UserNotFoundException {
	String message;
	public UserNotFoundException(String message) {
		this.message=message;
	}
	public String getMessage() {
		return message;
	}
}
