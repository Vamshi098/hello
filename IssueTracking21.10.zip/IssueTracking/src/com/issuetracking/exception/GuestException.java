package com.issuetracking.exception;

public class GuestException extends Exception {
}
