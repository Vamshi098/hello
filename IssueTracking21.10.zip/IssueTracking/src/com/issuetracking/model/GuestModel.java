package com.issuetracking.model;

public class GuestModel {	
public GuestModel() {}
private String Username;
private int MobileNumber;
private String Issue_Criticality;
private String Issue_Summary;
public String getUsername() {
	return Username;
}
public void setUsername(String username) {
	Username = username;
}
public int getMobileNumber() {
	return MobileNumber;
}
public void setMobileNumber(int mobileNumber) {
	MobileNumber = mobileNumber;
}
public String getIssue_Criticality() {
	return Issue_Criticality;
}
public void setIssue_Criticality(String issue_Criticality) {
	Issue_Criticality = issue_Criticality;
}
public String getIssue_Summary() {
	return Issue_Summary;
}
public void setIssue_Summary(String issue_Summary) {
	Issue_Summary = issue_Summary;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((Issue_Criticality == null) ? 0 : Issue_Criticality.hashCode());
	result = prime * result + ((Issue_Summary == null) ? 0 : Issue_Summary.hashCode());
	result = prime * result + MobileNumber;
	result = prime * result + ((Username == null) ? 0 : Username.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	GuestModel other = (GuestModel) obj;
	if (Issue_Criticality == null) {
		if (other.Issue_Criticality != null)
			return false;
	} else if (!Issue_Criticality.equals(other.Issue_Criticality))
		return false;
	if (Issue_Summary == null) {
		if (other.Issue_Summary != null)
			return false;
	} else if (!Issue_Summary.equals(other.Issue_Summary))
		return false;
	if (MobileNumber != other.MobileNumber)
		return false;
	if (Username == null) {
		if (other.Username != null)
			return false;
	} else if (!Username.equals(other.Username))
		return false;
	return true;
}
@Override
public String toString() {
	return "GuestModel [Username=" + Username + ", MobileNumber=" + MobileNumber + ", Issue_Criticality="
			+ Issue_Criticality + ", Issue_Summary=" + Issue_Summary + ", getUsername()=" + getUsername()
			+ ", getMobileNumber()=" + getMobileNumber() + ", getIssue_Criticality()=" + getIssue_Criticality()
			+ ", getIssue_Summary()=" + getIssue_Summary() + ", hashCode()=" + hashCode() + ", getClass()=" + getClass()
			+ ", toString()=" + super.toString() + "]";
}


}
