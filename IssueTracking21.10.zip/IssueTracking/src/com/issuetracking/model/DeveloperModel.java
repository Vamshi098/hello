package com.issuetracking.model;

public class DeveloperModel {
	public DeveloperModel() {

	}
 private int developer_ID;
 private String developer_Email_ID;
 private String developer_UserName;
 private String developer_password;;
 private String developer_Address;
 private int developer_Mobile_No;
 
public int getDeveloper_ID() {
	return developer_ID;
}
public void setDeveloper_ID(int developer_ID) {
	this.developer_ID = developer_ID;
}
public String getDeveloper_Email_ID() {
	return developer_Email_ID;
}
public void setDeveloper_Email_ID(String developer_Email_ID) {
	this.developer_Email_ID = developer_Email_ID;
}
public String getDeveloper_UserName() {
	return developer_UserName;
}
public void setDeveloper_UserName(String developer_UserName) {
	this.developer_UserName = developer_UserName;
}
public String getDeveloper_password() {
	return developer_password;
}
public void setDeveloper_password(String developer_password) {
	this.developer_password = developer_password;
}
public String getDeveloper_Address() {
	return developer_Address;
}
public void setDeveloper_Address(String developer_Address) {
	this.developer_Address = developer_Address;
}
public int getDeveloper_Mobile_No() {
	return developer_Mobile_No;
}
public void setDeveloper_Mobile_No(int developer_Mobile_No) {
	this.developer_Mobile_No = developer_Mobile_No;
}
@Override
public String toString() {
	return "DeveloperModel [developer_ID=" + developer_ID + ", developer_Email_ID=" + developer_Email_ID
			+ ", developer_UserName=" + developer_UserName + ", developer_password=" + developer_password
			+ ", developer_Address=" + developer_Address + ", developer_Mobile_No=" + developer_Mobile_No
			+ ", getDeveloper_ID()=" + getDeveloper_ID() + ", getDeveloper_Email_ID()=" + getDeveloper_Email_ID()
			+ ", getDeveloper_UserName()=" + getDeveloper_UserName() + ", getDeveloper_password()="
			+ getDeveloper_password() + ", getDeveloper_Address()=" + getDeveloper_Address()
			+ ", getDeveloper_Mobile_No()=" + getDeveloper_Mobile_No() + ", getClass()=" + getClass() + ", hashCode()="
			+ hashCode() + ", toString()=" + super.toString() + "]";
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((developer_Address == null) ? 0 : developer_Address.hashCode());
	result = prime * result + ((developer_Email_ID == null) ? 0 : developer_Email_ID.hashCode());
	result = prime * result + developer_ID;
	result = prime * result + developer_Mobile_No;
	result = prime * result + ((developer_UserName == null) ? 0 : developer_UserName.hashCode());
	result = prime * result + ((developer_password == null) ? 0 : developer_password.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	DeveloperModel other = (DeveloperModel) obj;
	if (developer_Address == null) {
		if (other.developer_Address != null)
			return false;
	} else if (!developer_Address.equals(other.developer_Address))
		return false;
	if (developer_Email_ID == null) {
		if (other.developer_Email_ID != null)
			return false;
	} else if (!developer_Email_ID.equals(other.developer_Email_ID))
		return false;
	if (developer_ID != other.developer_ID)
		return false;
	if (developer_Mobile_No != other.developer_Mobile_No)
		return false;
	if (developer_UserName == null) {
		if (other.developer_UserName != null)
			return false;
	} else if (!developer_UserName.equals(other.developer_UserName))
		return false;
	if (developer_password == null) {
		if (other.developer_password != null)
			return false;
	} else if (!developer_password.equals(other.developer_password))
		return false;
	return true;
}
 
}


