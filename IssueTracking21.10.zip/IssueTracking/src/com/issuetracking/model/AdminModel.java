package com.issuetracking.model;

public class AdminModel 
{
public AdminModel()
{
		
	}
		

}
