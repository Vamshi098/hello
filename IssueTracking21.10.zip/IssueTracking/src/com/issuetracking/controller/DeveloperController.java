package com.issuetracking.controller;
import java.sql.SQLException;
import java.util.List;
import com.issuetracking.helper.FactoryDeveloperService;
import com.issuetracking.model.TicketClassModel;
import com.issuetracking.service.DeveloperService;
import com.issuetracking.view.DeveloperView;
public class DeveloperController {
	private  DeveloperService developerService;
	DeveloperView developerView =new DeveloperView();
	public DeveloperController()
	{
		this.developerService=FactoryDeveloperService.createDeveloperService();
	}
	public List<TicketClassModel> handleviewTickets() throws ClassNotFoundException, SQLException {
		List<TicketClassModel> ticketClassModels=developerService.viewTickets();
		return ticketClassModels;
	}
	public List<TicketClassModel> handleassignTickets() throws ClassNotFoundException, SQLException{
		List<TicketClassModel> ticketClassModels=developerService.assignTickets();
		return ticketClassModels;
	}
	public List<TicketClassModel> handlesearchTickets() throws ClassNotFoundException, SQLException {
		List<TicketClassModel> ticketClassModels=developerService.searchTickets();
		return ticketClassModels;
	}
}

