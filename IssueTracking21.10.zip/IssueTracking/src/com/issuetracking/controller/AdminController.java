package com.issuetracking.controller;
import java.sql.SQLException;
import java.util.List;
import com.issuetracking.helper.FactoryAdminService;
import com.issuetracking.model.DeveloperModel;
import com.issuetracking.model.TicketClassModel;
import com.issuetracking.service.AdminService;
import com.issuetracking.view.AdminView;
public class AdminController 
{
	private  AdminService adminService;
	AdminView adminView =new AdminView();
	public AdminController()
	{
		this.adminService=FactoryAdminService.createAdminService();
	}
	public List<TicketClassModel> handleviewTickets() throws ClassNotFoundException, SQLException {
		System.out.print("controller");
		List<TicketClassModel> ticketClassModels=adminService.viewTickets();
		return ticketClassModels;
	}
	public List<DeveloperModel> handleretrieveDeveloper()  throws ClassNotFoundException, SQLException
	{
		System.out.println("controllers");
		List<DeveloperModel> developerModels=adminService.retrieveDevelopers();
		return developerModels;
	}
	public  List<DeveloperModel> handleunassignTicket() throws ClassNotFoundException, SQLException 
	{
		List<DeveloperModel> developerModels=adminService.retrieveunassignTicket();
		return developerModels;
	}
	public void handlecloseTicket() {
	}
	public List<TicketClassModel> handlesearchTickets() throws ClassNotFoundException,SQLException
	{
		List<TicketClassModel> ticketClassModels=adminService.searchTickets();
		return ticketClassModels;

	}
	public List<TicketClassModel> handlecloseTickets() throws ClassNotFoundException,SQLException
	{
		List<TicketClassModel> ticketClassModels=adminService.closeTickets();
		return ticketClassModels;
	}
}
