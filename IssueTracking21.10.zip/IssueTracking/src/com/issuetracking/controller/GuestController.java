package com.issuetracking.controller;

import java.sql.SQLException;

import com.issuetracking.helper.FactoryGuestService;
import com.issuetracking.model.GuestModel;
import com.issuetracking.service.GuestService;
import com.issuetracking.view.GuestView;

public class GuestController {
	private GuestService GuestService;

	public GuestController() {
		this.GuestService=FactoryGuestService.createGuestService();
	}
	public void handleRaiseTicket(GuestModel guestModel) throws ClassNotFoundException, SQLException {
		String output=GuestService.raiseTicket(guestModel);
		GuestView guestView=new GuestView();
		if(output.contentEquals("success")) {
			guestView.registerSuccess();
		}

	}

}