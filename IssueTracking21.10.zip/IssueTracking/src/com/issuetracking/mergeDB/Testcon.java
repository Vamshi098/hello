package com.issuetracking.mergeDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Testcon {
private static DataSource dataSource=new DataSource();
	public static void main(String[] args) 
	{
		try {
			Class.forName(dataSource.getDriver());
		Connection connection=DriverManager.getConnection(dataSource.getUrl(),dataSource.getUsername(),dataSource.getPassword());
	Statement statement=	connection.createStatement();
ResultSet resultSet=	statement.executeQuery(" select * from tickets");
while(resultSet.next())
{
	System.out.print(resultSet.getInt(1));
	System.out.println(resultSet.getString(2));
}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
