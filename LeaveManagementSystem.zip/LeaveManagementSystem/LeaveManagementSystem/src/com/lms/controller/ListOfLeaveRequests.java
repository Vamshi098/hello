package com.lms.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

import com.lms.dao.EmployeeDao;
import com.lms.dao.JDBCEmployeeDao;
import com.lms.dao.ManagerDAO;
import com.lms.entities.Employee;
import com.lms.entities.Leaves;
import com.lms.service.EmployeeServiceImp;
import com.lms.service.ManagerService;

@WebServlet("/ListOfLeaveRequests")
public class ListOfLeaveRequests extends HttpServlet {
	private static final long serialVersionUID = 1L;
	   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Logger logger = Logger.getLogger(LeaveRequestController.class);
		BasicConfigurator.configure();
		Employee employee = null;
		
		HttpSession session = request.getSession();
		int empId = (int) session.getAttribute("empId");
		
		ManagerService managerService = new ManagerService();
		JDBCEmployeeDao employeeDao = new JDBCEmployeeDao();
		
		try 
		{
			employee = employeeDao.getEmployeeById(empId);
			
		} catch (ClassNotFoundException | SQLException e1) 
		{
			
			logger.fatal(e1);
		}
		String leaveType = request.getParameter("leaveType");
		String fromDate = request.getParameter("from_date");
		String toDate = request.getParameter("to_date");
		String leaveId=request.getParameter("leave_Id");
		String emp_Id=request.getParameter("emp_Id");
		String designation=request.getParameter("designation");
		String leaveStatus=request.getParameter("status");
		String leave_description=request.getParameter("leave_description");
		
		
		
		Leaves leave = new Leaves(emp_Id, leaveType, fromDate, toDate, employee.getDesignation() ,leaveDescription);
		try {
			
			if(managerService.LeaveList())
			{
				request.getRequestDispatcher("employeePage.jsp").forward(request, response);
			}
		} catch (ClassNotFoundException e) {
			
			logger.fatal(e);
		} catch (SQLException e) {
			
			logger.fatal(e);
		}
		
		System.out.println(leaveType + fromDate + toDate + leaveDescription + employee.getDesignation());
		
	}
	

}
