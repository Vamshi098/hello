package com.lms.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

import com.lms.entities.LeaveBalance;
import com.lms.service.LeaveServiceImpl;

@WebServlet("/ViewEmployeeController")
public class ViewEmployeeController extends HttpServlet
{
	private static final long serialVersionUID = 1L;
    
	   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		Logger logger = Logger.getLogger(ViewEmployeeController.class);
		BasicConfigurator.configure();
		HttpSession session = request.getSession();
		
		LeaveBalance leaveBalance = null;
		
		LeaveServiceImpl leaveService = new LeaveServiceImpl();
		try 
		{
			leaveBalance = leaveService.viewLeaveBalances(empId);
			//System.out.println(leaveBalance.getEarnedLeave() + " "  + leaveBalance.getSickLeave() + " " +  leaveBalance.getBereavementLeave());
			
			request.setAttribute("leaveBalance", leaveBalance);
			
			request.getRequestDispatcher("/employeePage.jsp").forward(request, response);
			
		} catch (ClassNotFoundException | SQLException e) {
			
			logger.fatal(e);
		}
		
}
