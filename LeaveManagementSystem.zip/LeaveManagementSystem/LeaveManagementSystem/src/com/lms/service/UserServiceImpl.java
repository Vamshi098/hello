package com.lms.service;

import java.sql.SQLException;

import com.lms.dao.JDBCEmployeeDao;
import com.lms.dao.JDBCUserDao;

public class UserServiceImpl implements UserService 
{
	JDBCUserDao userDao = new JDBCUserDao();
	public String employeeLogin(int empId, String password) 
	{
		String empType = "";
		String empStr = String.valueOf(empId);
		try {
			if(userDao.employeeLogin(empId, password)) // if any record present in data base status will become true
			{
				if(empStr.substring(0, 3).equals("806"))
				{
					empType = "emp";
					//validate with employee table
				}
				if(empStr.substring(0, 3).equals("807"))
				{
					empType = "hr";
				}
				if(empStr.substring(0, 3).equals("805"))
				{
					empType = "mgr";
				}
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return empType;
	}
}
