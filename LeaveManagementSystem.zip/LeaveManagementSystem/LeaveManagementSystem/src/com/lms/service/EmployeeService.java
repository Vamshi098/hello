package com.lms.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.lms.dao.JDBCEmployeeDao;
import com.lms.entities.LeaveBalance;
import com.lms.entities.Leaves;

public interface EmployeeService 
{
	public ArrayList<Leaves> viewRequestStatus(int empId) throws ClassNotFoundException, SQLException ;
	public boolean requestLeave(Leaves leave, int empId) throws ClassNotFoundException, SQLException ;
}
