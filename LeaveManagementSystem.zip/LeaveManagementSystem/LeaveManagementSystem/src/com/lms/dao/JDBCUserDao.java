package com.lms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.lms.integrate.ConnectionManager;

public class JDBCUserDao implements UserDao
{

	@Override
	public boolean employeeLogin(int empId, String password) throws ClassNotFoundException, SQLException {
		System.out.println(empId + " " + password);
		boolean status = false;
		Connection connection = ConnectionManager.openConnection();
		PreparedStatement statement = connection.prepareStatement("select * from user where emp_id = ? and password = ?");
		
		statement.setInt(1, empId);
		statement.setString(2, password);
		ResultSet resultSet = statement.executeQuery();
	
		
		while(resultSet.next()) {
			status=true;
		}
		return status;
	}
	
}
