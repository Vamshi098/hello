package com.lms.test;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.Test;
import org.omg.CORBA.UserException;

import com.lms.entities.User;
import com.lms.service.UserServiceImpl;

public class TestUserLogin 
{

	@Test
	public void testUserAuthenticationService_positive() throws ClassNotFoundException, SQLException {
		UserServiceImpl userServiceImpl=new UserServiceImpl();
		User user=new User();
		user.setEmpId(8065679);
		user.setPassword("password");
		String actual=userServiceImpl.employeeLogin(user.getEmpId(),user.getPassword());
		String expected="emp";
		assertEquals(expected,actual);
	}
	
	@Test
	public void testUserAuthenticationService_negative() throws ClassNotFoundException, SQLException {
		 UserServiceImpl userServiceImpl=new UserServiceImpl();
		User user=new User();
		user.setEmpId(8065679);
		user.setPassword("passwor");
		String actual=userServiceImpl.employeeLogin(user.getEmpId(),user.getPassword());
		String expected="emp";
		assertTrue(false);
	}
}
