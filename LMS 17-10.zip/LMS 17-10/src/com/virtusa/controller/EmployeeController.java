package com.virtusa.controller;

import java.sql.SQLException;


import java.util.ArrayList;

import com.virtusa.entities.LeaveBalance;
import com.virtusa.entities.Leaves;
import com.virtusa.service.EmployeeServiceImp;


public class EmployeeController 
{
	EmployeeServiceImp empService = new EmployeeServiceImp();
	
	public ArrayList<Leaves> viewRequestStatus(int empId) throws ClassNotFoundException, SQLException {
		
		return empService.viewRequestStatus(empId);
	}
	public LeaveBalance viewLeaveBalances(int empId) throws ClassNotFoundException, SQLException {
		
		return empService.viewLeaveBalances(empId);
	}
	public boolean requestLeave(Leaves leave, int empId) throws ClassNotFoundException, SQLException {
		
		return empService.requestLeave(leave, empId);
	}
	
}
