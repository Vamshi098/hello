package com.virtusa.DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.entities.Leaves;


public interface LeaveDao 
{
	public static List<Leaves> getAllLeaveTypes() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return null;
	}
}
