package com.virtusa.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.entities.Leaves;
import com.virtusa.integrate.ConnectionManager;
import com.virtusa.model.ManagerLeaveModel;

public class ManagerDAOImpl implements ManagerDAO {
	
	public List<Leaves> getListOfLeaves() throws ClassNotFoundException, SQLException {
		Connection connection=ConnectionManager.openConnection();
		Statement statement=connection.createStatement();
		ResultSet resultSet=
				statement.executeQuery("select * from leaves_table");
		List<Leaves> listOfLeaveRequest=new ArrayList<Leaves>();
		while(resultSet.next()) {
			Leaves leaves=new Leaves();
			leaves.setLeaveId(resultSet.getInt("leave_Id"));
			leaves.setEmpId(resultSet.getInt("emp_Id"));
			leaves.setLeaveType(resultSet.getString("leave_Type"));
			leaves.setLeaveStatus(resultSet.getString("status"));
			leaves.setFromDate(resultSet.getString("from_Date"));
			leaves.setToDate(resultSet.getString("to_Date"));
			leaves.setDesignation(resultSet.getString("designation"));
			listOfLeaveRequest.add(leaves);
			System.out.println(leaves);
		}
		ConnectionManager.closeConnection();
		return listOfLeaveRequest;
	}
	public List<ManagerLeaveModel> checkLeaveBalances(int empId)throws ClassNotFoundException, SQLException {
		
		Connection connection=ConnectionManager.openConnection();
		PreparedStatement statement=connection.prepareStatement("select * from leavebalance where emp_id=?");
		statement.setInt(1, empId);
		ResultSet resultSet=statement.executeQuery();
		List<ManagerLeaveModel> leaveDetails=new ArrayList<ManagerLeaveModel>();
		ManagerLeaveModel managerLeaveModel=new ManagerLeaveModel();
		if(resultSet.next()) {
			managerLeaveModel.setEmp_id(resultSet.getInt("emp_id"));
			managerLeaveModel.setSick_leaves(resultSet.getInt("sick_leaves"));
			managerLeaveModel.setEarned_leaves(resultSet.getInt("earned_leaves"));
			managerLeaveModel.setBevarement_leaves(resultSet.getInt("bevarement_leaves"));
			leaveDetails.add(managerLeaveModel);
		}
		return leaveDetails;
	}
	

}
