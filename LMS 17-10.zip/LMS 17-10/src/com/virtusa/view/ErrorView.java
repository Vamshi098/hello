package com.virtusa.view;

public class ErrorView {
public static void error() {
		
		System.out.println("User Authentication Failed.");
		
	}

}
