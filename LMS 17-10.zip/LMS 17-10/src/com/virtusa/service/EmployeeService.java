package com.virtusa.service;

import java.sql.ResultSet;


import java.sql.SQLException;
import java.util.ArrayList;
import com.virtusa.DAO.EmployeeDaoImpl;
import com.virtusa.entities.LeaveBalance;
import com.virtusa.entities.Leaves;

public interface EmployeeService 
{
	EmployeeDaoImpl empDao = new EmployeeDaoImpl();
	
	public abstract ArrayList<Leaves> viewRequestStatus(int empId) throws ClassNotFoundException, SQLException;
		
	public abstract LeaveBalance viewLeaveBalances(int empId) throws ClassNotFoundException, SQLException;
	
	public abstract boolean requestLeave(Leaves leave, int empId) throws ClassNotFoundException, SQLException; 
}
