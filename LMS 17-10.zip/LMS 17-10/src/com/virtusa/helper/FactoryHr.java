package com.virtusa.helper;

import com.virtusa.DAO.EmployeeDao;
import com.virtusa.DAO.HrDao;
import com.virtusa.DAO.HrDaoImpl;
import com.virtusa.service.HrService;
import com.virtusa.service.HrServiceImpl;

public class FactoryHr {
		
	public static HrService createHrService()
	{
		HrService hrservice=new HrServiceImpl();
		return hrservice;	
	}
	
	public static HrDao createHrDao()
	{
		HrDao hrdao=new HrDaoImpl();
		return hrdao;
	}
}
