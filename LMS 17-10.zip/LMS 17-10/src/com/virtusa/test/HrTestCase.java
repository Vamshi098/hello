package com.virtusa.test;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.Test;

import com.virtusa.DAO.HrDao;
import com.virtusa.DAO.HrDaoImpl;
import com.virtusa.entities.Employee;

public class HrTestCase 
{
	
    @Test
    void updateEmployeeDesignationtest_postive() {
       
        Employee employee=new Employee();
        HrDao hrdao=new HrDaoImpl();   
        employee.setEmployeeId(103);
        employee.setDesignation("engineer");
        try {
            boolean actualResult=hrdao.updateEmployeeDesignation(employee);
            boolean expected=true;
            assertEquals(actualResult,expected);           
        } catch (ClassNotFoundException e) {
            assertTrue(true);
            e.printStackTrace();
        } catch (SQLException e) {
            assertTrue(true);
            e.printStackTrace();
        }       
    }
   
    @Test
    void updateEmployeeDesignationtest_negative() {
       
        Employee employee=new Employee();
        HrDao hrdao=new HrDaoImpl();   
        employee.setEmployeeId(100);
        employee.setDesignation("engineer");
        try {
            boolean actualResult=hrdao.updateEmployeeDesignation(employee);
            boolean expected=false;
            assertEquals(actualResult,expected);           
        } catch (ClassNotFoundException e) {
            assertTrue(true);
            e.printStackTrace();
        } catch (SQLException e) {
            assertTrue(true);
            e.printStackTrace();
        }       
    }
    @Test
    void updateEmployeePhoneNumbertest_postive() {

        Employee employee=new Employee();
        HrDao hrdao=new HrDaoImpl();   
        employee.setEmployeeId(103);
        employee.setPhoneNumber("919866659596");
        try {
            boolean actualResult=hrdao.updateEmployeeSalary(employee);
            boolean expected=true;
            assertEquals(actualResult,expected);           
        } catch (ClassNotFoundException e) {
            assertTrue(true);
            e.printStackTrace();
        } catch (SQLException e) {
            assertTrue(true);
            e.printStackTrace();
        }               
    }
    @Test
    void updateEmployeePhoneNumbertest_negative() {
        Employee employee=new Employee();
        HrDao hrdao=new HrDaoImpl();   
        employee.setEmployeeId(100);
        employee.setPhoneNumber("919494728414");
        try {
            boolean actualResult=hrdao.updateEmployeeSalary(employee);
            boolean expected=false;
            assertEquals(actualResult,expected);           
        } catch (ClassNotFoundException e) {
            assertTrue(true);
            
            e.printStackTrace();
        } catch (SQLException e) {
            assertTrue(true);
           
            e.printStackTrace();
        }               
    }   
    @Test
    void SalaryUpdateTest_postive() {
       
        Employee employee=new Employee();
        HrDao hrdao=new HrDaoImpl();   
        employee.setEmployeeId(109);
        employee.setSalary(32000);
        try {
            boolean actualResult=hrdao.updateEmployeeSalary(employee);
            boolean expected=true;
            assertEquals(actualResult,expected);           
        } catch (ClassNotFoundException e) {
            assertTrue(true);
            e.printStackTrace();
        } catch (SQLException e) {
            assertTrue(true);
          
            e.printStackTrace();
        }               
    }
    @Test
    void SalaryUpdateTest_negative() {
       
        Employee employee=new Employee();
        HrDao hrdao=new HrDaoImpl();   
        employee.setEmployeeId(100);
        employee.setSalary(32000);
        try {
            boolean actualResult=hrdao.updateEmployeeSalary(employee);
            boolean expected=false;
            assertEquals(actualResult,expected);           
        } catch (ClassNotFoundException e) {
            assertTrue(true);
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            assertTrue(true);
            // TODO Auto-generated catch block
            e.printStackTrace();
        }               
    }

}
