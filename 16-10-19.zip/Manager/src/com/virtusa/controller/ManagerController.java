package com.virtusa.controller;

import java.sql.SQLException;
import com.virtusa.dao.ManagerDAOImpl;
import com.virtusa.service.ManagerServiceImpl;
import com.virtusa.view.ManagerView;

public class ManagerController {

	public void viewListOfLeaveRequests() throws ClassNotFoundException, SQLException 
	{
		/*ArrayList<Leaves> requestList = new ArrayList();
		
		ManagerDAO managerDAO=new ManagerDAO();
		requestList = (ArrayList<Leaves>) managerDAO.getListOfLeaves();
		for(int i =0; i<requestList.size();i++)
		{
			System.out.println(requestList.get(i).toString());
		}*/
		
		ManagerDAOImpl managerDAOImpl=new ManagerDAOImpl();
		managerDAOImpl.getListOfLeaves();
		ManagerServiceImpl managerServiceImpl=new ManagerServiceImpl();
		managerServiceImpl.leaveList();
	}
	public void leavebalances(int empId) throws ClassNotFoundException, SQLException {
		ManagerDAOImpl managerDAOImpl=new ManagerDAOImpl();
		managerDAOImpl.checkLeaveBalances(empId);
		
		/*ManagerService managerService=new ManagerService();
		managerService.leaveBalances();*/
	}
	public void approveLeave(int empId) throws ClassNotFoundException, SQLException {
		ManagerServiceImpl managerServiceImpl=new ManagerServiceImpl();
		managerServiceImpl.leaveApproval(empId);
		
		ManagerView managerView=new ManagerView();
		managerView.managerPage();
	}
	public void rejectLeave(int empId) throws ClassNotFoundException, SQLException {
		ManagerServiceImpl managerServiceImpl=new ManagerServiceImpl();
		managerServiceImpl.leaveRejection(empId);
		
		ManagerView managerView=new ManagerView();
		managerView.managerPage();
	}

}
