package com.virtusa.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.virtusa.service.ManagerServiceImpl;

public class TestManagerService {

	@Test
	public void positive_Test() {
		ManagerServiceImpl managerServiceImpl=new ManagerServiceImpl();
		
		fail("Not yet implemented");
	}

}
