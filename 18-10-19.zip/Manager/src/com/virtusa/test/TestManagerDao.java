package com.virtusa.test;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.List;

import org.junit.Test;

import com.virtusa.dao.ManagerDAOImpl;
import com.virtusa.entities.Leaves;
import com.virtusa.model.ManagerLeaveModel;

public class TestManagerDao {

	@Test
	public void positive_Test() {
		ManagerDAOImpl managerDAOImpl=new ManagerDAOImpl();
		try {
			List<Leaves> leaveList=
					managerDAOImpl.getListOfLeaves();
			assertEquals(true,leaveList.size()>0);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			assertTrue(false);
		}
	}
	
	
		@Test
		public void positive_checkLeaveBalanceTest() {
			int empId=2058;
			ManagerDAOImpl managerDAOImpl=new ManagerDAOImpl();
			try {
				List<ManagerLeaveModel> managerLeaveModel=
						managerDAOImpl.checkLeaveBalances(empId);
				assertEquals(true,managerLeaveModel.size()>0);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				assertTrue(false);
			}
	}
	
	

}
