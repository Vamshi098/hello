package com.virtusa.service;

import java.sql.SQLException;

public interface ManagerService {

	void leaveBalances() throws ClassNotFoundException, SQLException;
	void leaveApproval(int empId) throws ClassNotFoundException, SQLException;
	void leaveRejection(int empId) throws ClassNotFoundException, SQLException;
	void leaveList() throws ClassNotFoundException, SQLException;
}
