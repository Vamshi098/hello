package com.virtusa.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.dao.ManagerDAO;
import com.virtusa.dao.ManagerDAOImpl;
import com.virtusa.entities.Leaves;
import com.virtusa.helper.FactoryManagerDB;
import com.virtusa.model.EmployeesModel;
import com.virtusa.service.ManagerService;

/**
 * Servlet implementation class ManagerController
 */
@WebServlet("/manager")
public class ManagerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ManagerService managerService=null;
	private ManagerDAO managerDAO=null;
    /**
     * Default constructor. 
     */
    public ManagerController() {
        // TODO Auto-generated constructor stub
    	super();
    }

    @Override
    public void init(ServletConfig config) throws ServletException {
    	super.init(config);
    	this.managerService=FactoryManagerDB.listLeavesManagerService();
    	this.managerDAO=FactoryManagerDB.listLeavesManagerDAO();
    	
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action=request.getParameter("action");
		if(action.contentEquals("list")) {
			List<Leaves> leaveList=managerDAO.getListOfLeaves();
			request.setAttribute("employeesModelList", employeesModelList);
			
			if(!employeesModelList.isEmpty()) {
				
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("employeefullnamedetails.jsp");
				dispatcher.forward(request,response);
			}else {
				RequestDispatcher dispatcher=
						request.getRequestDispatcher("noemployeedetails.jsp");
				dispatcher.forward(request,response);
			}
			}
			
			
		
		}
	}

}
