package com.virtusa.service;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.entities.Leaves;

public interface ManagerService {

	public void leaveBalances() throws ClassNotFoundException, SQLException;
	public void leaveApproval(int empId) throws ClassNotFoundException, SQLException;
	public void leaveRejection(int empId) throws ClassNotFoundException, SQLException;
	public void leaveList() throws ClassNotFoundException, SQLException;
}
